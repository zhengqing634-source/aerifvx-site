import React from 'react'

/** AeRifvX 品牌标志：三角晶格 + 内核（黑曜石 / 银白 / 冰蓝） */
export function BrandMark({ size = 30, animated = false }) {
  return (
    <svg
      className="brand-mark"
      width={size}
      height={size}
      viewBox="0 0 64 64"
      fill="none"
      aria-hidden="true"
    >
      <path
        d="M32 4 58 52H6z"
        stroke="#8FC7FF"
        strokeWidth="4"
        strokeLinejoin="round"
        fill="none"
        className={animated ? 'draw' : ''}
      />
      <path
        d="M32 24 44 46H20z"
        fill="#E8EDF4"
        className={animated ? 'fill' : ''}
      />
    </svg>
  )
}

/** 启动动画 Logo（线稿描边绘制版） */
export function PreloaderMark() {
  return (
    <svg viewBox="0 0 64 64" fill="none" aria-hidden="true">
      <path
        className="draw"
        d="M32 4 58 52H6z"
        stroke="#8FC7FF"
        strokeWidth="3"
        strokeLinejoin="round"
      />
      <path className="draw draw-2" d="M32 24 44 46H20z" stroke="#E8EDF4" strokeWidth="2.4" strokeLinejoin="round" />
      <path className="fill" d="M32 24 44 46H20z" fill="#E8EDF4" opacity="0.9" />
    </svg>
  )
}

export default BrandMark
