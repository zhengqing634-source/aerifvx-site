import React, { useEffect, useState } from 'react'

/**
 * 路由加载动画（懒加载过渡）
 * - 常规：品牌旋转光圈
 * - 网络不佳（>1.8s）：追加「网络较慢」呼吸动画
 * - 长时间无响应（>8s）：提供重新加载入口
 */
export default function RouteLoader() {
  const [slow, setSlow] = useState(false)
  const [stuck, setStuck] = useState(false)

  useEffect(() => {
    const t1 = setTimeout(() => setSlow(true), 1800)
    const t2 = setTimeout(() => setStuck(true), 8000)
    return () => {
      clearTimeout(t1)
      clearTimeout(t2)
    }
  }, [])

  return (
    <div className="route-loader" role="status" aria-label="页面加载中">
      <div className="loader-stack">
        <div className="spinner" />
        {!slow && <p className="loader-label">加载中</p>}

        {slow && !stuck && (
          <div className="slow-note" role="status">
            <span className="slow-bars" aria-hidden="true">
              <i /><i /><i /><i />
            </span>
            <p>网络较慢，正在努力加载…</p>
          </div>
        )}

        {stuck && (
          <div className="slow-note" role="status">
            <span className="slow-bars" aria-hidden="true">
              <i /><i /><i /><i />
            </span>
            <p>加载时间较长，可能是网络不稳定</p>
            <button type="button" className="btn btn--ghost" onClick={() => window.location.reload()}>
              重新加载
            </button>
          </div>
        )}
      </div>
    </div>
  )
}
