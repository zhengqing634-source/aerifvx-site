import React, { useEffect, useRef } from 'react'

/**
 * 轻量视差：滚动时以 transform 位移元素（不触发布局重排）
 * speed > 0 向下慢移，speed < 0 向上慢移
 */
export default function Parallax({ children, speed = 0.12, className = '', ...rest }) {
  const ref = useRef(null)

  useEffect(() => {
    const el = ref.current
    if (!el) return
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return

    let raf = null
    const update = () => {
      raf = null
      const rect = el.getBoundingClientRect()
      const center = rect.top + rect.height / 2 - window.innerHeight / 2
      el.style.transform = `translate3d(0, ${(-center * speed).toFixed(2)}px, 0)`
    }
    const onScroll = () => {
      if (raf === null) raf = requestAnimationFrame(update)
    }
    update()
    window.addEventListener('scroll', onScroll, { passive: true })
    window.addEventListener('resize', onScroll)
    return () => {
      window.removeEventListener('scroll', onScroll)
      window.removeEventListener('resize', onScroll)
      if (raf !== null) cancelAnimationFrame(raf)
    }
  }, [speed])

  return (
    <div ref={ref} className={`parallax-layer ${className}`} {...rest}>
      {children}
    </div>
  )
}
