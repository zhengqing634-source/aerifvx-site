import React, { useRef } from 'react'
import { Link } from 'react-router-dom'

/**
 * 统一按钮 / 链接按钮：点击波纹反馈 + 箭头位移动效
 * to → 路由链接；href → 外链；否则为 button
 */
export default function Btn({
  children,
  to,
  href,
  variant = 'ghost',
  arrow = true,
  className = '',
  onClick,
  type = 'button',
  disabled = false,
  magnetic = true,
  ...rest
}) {
  const ref = useRef(null)

  /* 磁性按钮：鼠标靠近时轻微跟随（仅精确指针设备，transform 实现） */
  const handleMove = (e) => {
    if (!magnetic || disabled) return
    if (!window.matchMedia('(pointer: fine)').matches) return
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return
    const el = ref.current
    if (!el) return
    const rect = el.getBoundingClientRect()
    const x = (e.clientX - rect.left - rect.width / 2) * 0.18
    const y = (e.clientY - rect.top - rect.height / 2) * 0.3
    el.style.setProperty('--mag-x', `${x.toFixed(2)}px`)
    el.style.setProperty('--mag-y', `${y.toFixed(2)}px`)
  }

  const handleLeave = () => {
    const el = ref.current
    if (!el) return
    el.style.setProperty('--mag-x', '0px')
    el.style.setProperty('--mag-y', '0px')
  }

  const handleClick = (e) => {
    const el = ref.current
    if (el && !disabled) {
      const rect = el.getBoundingClientRect()
      const ripple = document.createElement('span')
      const size = Math.max(rect.width, rect.height)
      ripple.className = 'ripple'
      ripple.style.width = ripple.style.height = `${size}px`
      ripple.style.left = `${e.clientX - rect.left - size / 2}px`
      ripple.style.top = `${e.clientY - rect.top - size / 2}px`
      el.appendChild(ripple)
      setTimeout(() => ripple.remove(), 600)
    }
    if (onClick) onClick(e)
  }

  const cls = `btn btn--${variant} ${className}`
  const motion = { onMouseMove: handleMove, onMouseLeave: handleLeave }

  const inner = (
    <>
      {children}
      {arrow && <span className="btn-arrow" aria-hidden="true">→</span>}
    </>
  )

  if (to) {
    return (
      <Link ref={ref} to={to} className={cls} onClick={handleClick} {...motion} {...rest}>
        {inner}
      </Link>
    )
  }
  if (href) {
    return (
      <a ref={ref} href={href} className={cls} onClick={handleClick} {...motion} {...rest}>
        {inner}
      </a>
    )
  }
  return (
    <button ref={ref} type={type} className={cls} onClick={handleClick} disabled={disabled} {...motion} {...rest}>
      {inner}
    </button>
  )
}
