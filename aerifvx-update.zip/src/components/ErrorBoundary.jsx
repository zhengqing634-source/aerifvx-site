import React from 'react'

/**
 * 页面级错误边界：懒加载彻底失败 / 渲染异常时的兜底界面
 * 独立的「加载失败」动画，与断线动画区分开
 */
export default class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props)
    this.state = { failed: false, lastKey: props.resetKey }
  }

  static getDerivedStateFromError() {
    return { failed: true }
  }

  static getDerivedStateFromProps(props, state) {
    // 路由变化时自动复位，用户可通过导航自行恢复
    if (props.resetKey !== state.lastKey) {
      return { failed: false, lastKey: props.resetKey }
    }
    return null
  }

  componentDidCatch(error) {
    // 保留错误信息便于排查（不展示给用户）
    if (typeof console !== 'undefined') console.warn('[AeRifvX] 页面加载失败：', error)
  }

  render() {
    if (!this.state.failed) return this.props.children

    return (
      <div className="load-error-panel" role="alert">
        {/* 加载失败独立动画：断环旋转 + 感叹号脉冲 */}
        <svg className="error-anim" viewBox="0 0 120 120" aria-hidden="true">
          <circle
            className="ea-ring"
            cx="60"
            cy="60"
            r="42"
            fill="none"
            stroke="currentColor"
            strokeWidth="5"
            strokeLinecap="round"
            strokeDasharray="60 205"
          />
          <g className="ea-mark">
            <line x1="60" y1="38" x2="60" y2="66" stroke="currentColor" strokeWidth="7" strokeLinecap="round" />
            <circle cx="60" cy="82" r="4.6" fill="currentColor" />
          </g>
        </svg>
        <h2 className="display-s">页面加载失败</h2>
        <p className="muted">
          网络连接不稳定，资源未能成功加载。请检查网络后重试，或返回首页继续浏览。
        </p>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '1rem', justifyContent: 'center' }}>
          <button type="button" className="btn btn--primary" onClick={() => window.location.reload()}>
            重新加载
          </button>
          <a
            className="btn btn--ghost"
            href={window.location.pathname + '#/'}
            onClick={() => {
              window.location.hash = '#/'
              window.location.reload()
            }}
          >
            返回首页
          </a>
        </div>
      </div>
    )
  }
}
