import React, { useEffect, useRef } from 'react'

/**
 * 高性能粒子 / 微光背景（Canvas，仅 transform/opacity 思路，自动降帧）
 * - 粒子数量按视口面积自适应
 * - prefers-reduced-motion 时不绘制
 */
export default function ParticleField({ density = 0.00009, speed = 0.12, link = true }) {
  const ref = useRef(null)

  useEffect(() => {
    const canvas = ref.current
    if (!canvas) return
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return

    const ctx = canvas.getContext('2d')
    let raf
    let particles = []
    let w = 0
    let h = 0
    let dpr = Math.min(window.devicePixelRatio || 1, 2)
    let last = 0
    const FPS_INTERVAL = 1000 / 40

    const resize = () => {
      const rect = canvas.parentElement.getBoundingClientRect()
      w = rect.width
      h = rect.height
      canvas.width = w * dpr
      canvas.height = h * dpr
      canvas.style.width = `${w}px`
      canvas.style.height = `${h}px`
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
      const count = Math.min(140, Math.max(28, Math.round(w * h * density)))
      particles = Array.from({ length: count }, () => ({
        x: Math.random() * w,
        y: Math.random() * h,
        r: Math.random() * 1.7 + 0.35,
        vx: (Math.random() - 0.5) * speed,
        vy: (Math.random() - 0.5) * speed,
        a: Math.random() * 0.5 + 0.12
      }))
    }

    const draw = (ts) => {
      raf = requestAnimationFrame(draw)
      if (ts - last < FPS_INTERVAL) return
      last = ts
      ctx.clearRect(0, 0, w, h)

      for (const p of particles) {
        p.x += p.vx
        p.y += p.vy
        if (p.x < -8) p.x = w + 8
        if (p.x > w + 8) p.x = -8
        if (p.y < -8) p.y = h + 8
        if (p.y > h + 8) p.y = -8

        ctx.beginPath()
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2)
        ctx.fillStyle = `rgba(160, 205, 250, ${p.a})`
        ctx.fill()
      }

      if (link) {
        for (let i = 0; i < particles.length; i++) {
          for (let j = i + 1; j < particles.length; j++) {
            const a = particles[i]
            const b = particles[j]
            const dx = a.x - b.x
            const dy = a.y - b.y
            const dist = dx * dx + dy * dy
            if (dist < 12000) {
              const alpha = (1 - dist / 12000) * 0.12
              ctx.beginPath()
              ctx.moveTo(a.x, a.y)
              ctx.lineTo(b.x, b.y)
              ctx.strokeStyle = `rgba(143, 199, 255, ${alpha})`
              ctx.lineWidth = 0.7
              ctx.stroke()
            }
          }
        }
      }
    }

    resize()
    raf = requestAnimationFrame(draw)
    window.addEventListener('resize', resize)
    return () => {
      cancelAnimationFrame(raf)
      window.removeEventListener('resize', resize)
    }
  }, [density, speed, link])

  return <canvas ref={ref} className="particle-canvas" aria-hidden="true" />
}
