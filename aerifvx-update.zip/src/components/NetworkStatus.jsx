import React, { useEffect, useState } from 'react'

/**
 * 网络连接状态监测
 * - 网络无法连接（offline）：独立的断线动画覆盖层 + 重新连接
 * - 网络恢复：自动收起并轻提示
 */
export default function NetworkStatus() {
  const [offline, setOffline] = useState(false)
  const [restored, setRestored] = useState(false)

  useEffect(() => {
    const goOffline = () => {
      setRestored(false)
      setOffline(true)
    }
    const goOnline = () => {
      if (offline) {
        setOffline(false)
        setRestored(true)
        setTimeout(() => setRestored(false), 2600)
      }
    }

    if (typeof navigator !== 'undefined' && navigator.onLine === false) setOffline(true)

    window.addEventListener('offline', goOffline)
    window.addEventListener('online', goOnline)
    return () => {
      window.removeEventListener('offline', goOffline)
      window.removeEventListener('online', goOnline)
    }
  }, [offline])

  return (
    <>
      {/* 断线覆盖层（独立动画） */}
      <div className={`offline-overlay${offline ? ' show' : ''}`} aria-hidden={!offline}>
        <div className="offline-card">
          {/* 断线信号动画 */}
          <svg className="offline-anim" viewBox="0 0 120 90" aria-hidden="true">
            <g className="oa-waves" fill="none" stroke="currentColor" strokeWidth="4" strokeLinecap="round">
              <path className="oa-wave w1" d="M42 52a24 24 0 0 1 34 0" />
              <path className="oa-wave w2" d="M32 38a40 40 0 0 1 54 0" />
              <path className="oa-wave w3" d="M22 24a56 56 0 0 1 74 0" />
            </g>
            <circle className="oa-dot" cx="59" cy="66" r="5" fill="currentColor" />
            <line className="oa-slash" x1="18" y1="18" x2="100" y2="76" stroke="currentColor" strokeWidth="5" strokeLinecap="round" />
          </svg>
          <h3 className="display-s">网络无法连接</h3>
          <p className="muted">
            当前设备处于离线状态，页面内容暂时无法加载。请检查网络连接后重试。
          </p>
          <button
            type="button"
            className="btn btn--primary"
            onClick={() => window.location.reload()}
          >
            重新连接
          </button>
        </div>
      </div>

      {/* 网络恢复轻提示 */}
      <div className={`net-restore-toast${restored ? ' show' : ''}`} role="status" aria-live="polite">
        ✓ 网络已恢复，继续浏览
      </div>
    </>
  )
}
