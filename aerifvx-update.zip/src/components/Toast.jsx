import React, { useEffect, useRef, useState } from 'react'

/**
 * 全局轻提示（Toast）：用于复制成功等微交互反馈
 * 用法：调用 window.__aerifvxToast?.(message)
 */
export default function Toast() {
  const [msg, setMsg] = useState('')
  const timer = useRef(null)

  useEffect(() => {
    window.__aerifvxToast = (text) => {
      setMsg(text)
      clearTimeout(timer.current)
      timer.current = setTimeout(() => setMsg(''), 2400)
    }
    return () => {
      clearTimeout(timer.current)
      delete window.__aerifvxToast
    }
  }, [])

  return (
    <div className={`toast${msg ? ' show' : ''}`} role="status" aria-live="polite">
      <span className="toast-dot" aria-hidden="true">✓</span>
      {msg}
    </div>
  )
}

export function showToast(text) {
  if (typeof window !== 'undefined' && window.__aerifvxToast) window.__aerifvxToast(text)
}
