import React from 'react'
import { Link } from 'react-router-dom'
import ParticleField from './ParticleField'
import Reveal from './Reveal'

/**
 * 内页统一页头（含面包屑 / 装饰粒子层）
 */
export default function PageHead({ eyebrow, title, lede, crumbs = [] }) {
  return (
    <section className="page-head">
      <div className="aurora aurora--a" />
      <ParticleField density={0.00005} speed={0.08} link={false} />
      <div className="container">
        <Reveal>
          <div className="crumbs">
            <Link to="/">HOME</Link>
            {crumbs.map((c) => (
              <React.Fragment key={c.label}>
                <span className="sep">/</span>
                {c.to ? <Link to={c.to}>{c.label}</Link> : <span>{c.label}</span>}
              </React.Fragment>
            ))}
          </div>
        </Reveal>
        {eyebrow && (
          <Reveal delay={0.06}>
            <span className="eyebrow">{eyebrow}</span>
          </Reveal>
        )}
        <Reveal delay={0.12}>
          <h1 className="display-l">{title}</h1>
        </Reveal>
        {lede && (
          <Reveal delay={0.2}>
            <p className="lede">{lede}</p>
          </Reveal>
        )}
      </div>
    </section>
  )
}
