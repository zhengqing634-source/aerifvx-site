import React, { useState } from 'react'

/**
 * 手风琴 / FAQ 折叠面板（grid-template-rows 过渡，不动画 height）
 */
function AccordionItem({ item, index, open, onToggle }) {
  const id = `acc-panel-${index}`
  return (
    <div className={`acc-item${open ? ' open' : ''}`}>
      <button
        className="acc-head"
        onClick={onToggle}
        aria-expanded={open}
        aria-controls={id}
        type="button"
      >
        <span className="acc-q">{item.q}</span>
        <span className="acc-sign" aria-hidden="true">
          <i /><i />
        </span>
      </button>
      <div className="acc-body" id={id} role="region">
        <div className="acc-body-inner">
          <p>{item.a}</p>
        </div>
      </div>
    </div>
  )
}

export default function Accordion({ items = [], className = '', defaultOpen = -1 }) {
  const [openIdx, setOpenIdx] = useState(defaultOpen)

  return (
    <div className={`accordion ${className}`}>
      {items.map((item, i) => (
        <AccordionItem
          key={item.q}
          item={item}
          index={i}
          open={openIdx === i}
          onToggle={() => setOpenIdx(openIdx === i ? -1 : i)}
        />
      ))}
    </div>
  )
}
