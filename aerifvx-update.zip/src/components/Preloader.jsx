import React, { useEffect, useState } from 'react'
import { PreloaderMark } from './BrandMark'

/**
 * 品牌启动动画：Logo 线稿逐步显现 → 品牌字标 → 平滑淡出
 * - 遵循 prefers-reduced-motion：直接跳过
 * - 同一会话仅播放一次
 */
export default function Preloader() {
  const [done, setDone] = useState(() => {
    try {
      return sessionStorage.getItem('aerifvx-preloaded') === '1'
    } catch {
      return false
    }
  })

  useEffect(() => {
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    const delay = reduce ? 120 : 2250
    const t = setTimeout(() => {
      setDone(true)
      try {
        sessionStorage.setItem('aerifvx-preloaded', '1')
      } catch {
        /* ignore */
      }
    }, delay)
    return () => clearTimeout(t)
  }, [])

  return (
    <div className={`preloader${done ? ' done' : ''}`} aria-hidden={done}>
      <div className="preloader-inner">
        <PreloaderMark />
        <div className="preloader-word">AERIFVX</div>
        <div className="preloader-line"><i /></div>
      </div>
    </div>
  )
}
