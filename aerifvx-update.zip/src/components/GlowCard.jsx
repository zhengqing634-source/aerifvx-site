import React, { useRef } from 'react'

/**
 * 悬停光效卡片：鼠标跟随的柔和径向高光（纯 CSS 变量，零布局重排）
 */
export default function GlowCard({ children, className = '', as: Tag = 'div', ...rest }) {
  const ref = useRef(null)

  const onMove = (e) => {
    const el = ref.current
    if (!el) return
    const rect = el.getBoundingClientRect()
    el.style.setProperty('--mx', `${e.clientX - rect.left}px`)
    el.style.setProperty('--my', `${e.clientY - rect.top}px`)
  }

  return (
    <Tag ref={ref} className={`glow-card ${className}`} onMouseMove={onMove} {...rest}>
      {children}
    </Tag>
  )
}
