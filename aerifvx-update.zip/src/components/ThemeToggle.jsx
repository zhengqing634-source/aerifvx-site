import React, { useEffect, useState } from 'react'

/**
 * 全站深色 / 浅色主题切换（持久化到 localStorage）
 */
export default function ThemeToggle({ className = '' }) {
  const [light, setLight] = useState(() => {
    try {
      return localStorage.getItem('aerifvx-theme') === 'light'
    } catch {
      return false
    }
  })

  useEffect(() => {
    document.body.classList.toggle('light', light)
    try {
      localStorage.setItem('aerifvx-theme', light ? 'light' : 'dark')
    } catch {
      /* ignore */
    }
  }, [light])

  return (
    <button
      className={`theme-toggle ${className}`}
      onClick={() => setLight((v) => !v)}
      aria-label={light ? '切换到深色模式' : '切换到浅色模式'}
      title={light ? '深色模式' : '浅色模式'}
      type="button"
    >
      {light ? (
        <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" aria-hidden="true">
          <path d="M20.5 14.5A8.5 8.5 0 1 1 9.5 3.5a7 7 0 0 0 11 11Z" />
        </svg>
      ) : (
        <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" aria-hidden="true">
          <circle cx="12" cy="12" r="4" />
          <path d="M12 2.5v2.5M12 19v2.5M2.5 12H5M19 12h2.5M4.6 4.6l1.8 1.8M17.6 17.6l1.8 1.8M19.4 4.6l-1.8 1.8M6.4 17.6l-1.8 1.8" />
        </svg>
      )}
    </button>
  )
}
