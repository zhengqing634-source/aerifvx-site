import React from 'react'

/**
 * 线性图标集（统一 1.4 描边，黑曜石风格）
 */
const paths = {
  chain: (
    <>
      <circle cx="12" cy="12" r="8.2" />
      <path d="M12 3.8v16.4M3.8 12h16.4M6.2 6.2l11.6 11.6M17.8 6.2 6.2 17.8" />
    </>
  ),
  globe: (
    <>
      <circle cx="12" cy="12" r="8.6" />
      <path d="M3.4 12h17.2M12 3.4c2.6 2.6 3.9 5.6 3.9 8.6s-1.3 6-3.9 8.6c-2.6-2.6-3.9-5.6-3.9-8.6s1.3-6 3.9-8.6Z" />
    </>
  ),
  game: (
    <>
      <rect x="2.6" y="7.2" width="18.8" height="10.4" rx="4.6" />
      <path d="M7.4 10.6v3.6M5.6 12.4h3.6M15.8 11.6h.02M18.2 13.8h.02" />
    </>
  ),
  video: (
    <>
      <rect x="2.8" y="5.6" width="13.4" height="12.8" rx="3" />
      <path d="m16.2 10.4 5-2.8v8.8l-5-2.8M6.2 12h3.6" />
    </>
  ),
  window: (
    <>
      <rect x="3" y="4.4" width="18" height="15.2" rx="2.8" />
      <path d="M3 9.2h18M6.6 6.8h.02M9.2 6.8h.02" />
    </>
  ),
  app: (
    <>
      <rect x="6.6" y="2.8" width="10.8" height="18.4" rx="3" />
      <path d="M10.4 18.2h3.2M9.6 6.4h4.8" />
    </>
  ),
  arrow: <path d="M5 12h14M13 6l6 6-6 6" />,
  check: <path d="m5 12.5 4.5 4.5L19 7.5" />,
  mail: (
    <>
      <rect x="3" y="5.4" width="18" height="13.2" rx="2.6" />
      <path d="m3.6 7 8.4 6.2L20.4 7" />
    </>
  ),
  search: (
    <>
      <circle cx="11" cy="11" r="7" />
      <path d="m16.2 16.2 4.4 4.4" />
    </>
  ),
  spark: (
    <>
      <path d="M12 2.8 14 9.6l6.8 2-6.8 2-2 6.8-2-6.8-6.8-2 6.8-2z" />
    </>
  )
}

export default function Icon({ name = 'spark', size = 44, className = '' }) {
  return (
    <svg
      className={`ico ${className}`}
      width={size}
      height={size}
      viewBox="0 0 24 24"
      aria-hidden="true"
    >
      {paths[name] || paths.spark}
    </svg>
  )
}
