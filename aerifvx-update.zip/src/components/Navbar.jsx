import React, { useEffect, useState } from 'react'
import { NavLink, Link, useLocation } from 'react-router-dom'
import { BrandMark } from './BrandMark'
import ThemeToggle from './ThemeToggle'
import { company } from '../data/siteData'

const NAV_ITEMS = [
  { to: '/', label: '首页', idx: '01' },
  { to: '/crypto', label: '加密生态', idx: '02' },
  { to: '/web4', label: 'Web4 技术', idx: '03' },
  { to: '/services', label: '技术服务', idx: '04' },
  { to: '/about', label: '企业介绍', idx: '05' },
  { to: '/team', label: '核心团队', idx: '06' },
  { to: '/news', label: '公告中心', idx: '07' }
]

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen] = useState(false)
  const location = useLocation()

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  // 路由切换时关闭移动菜单
  useEffect(() => {
    setOpen(false)
  }, [location.pathname])

  // 移动菜单打开时锁定滚动
  useEffect(() => {
    document.body.style.overflow = open ? 'hidden' : ''
    return () => {
      document.body.style.overflow = ''
    }
  }, [open])

  return (
    <>
      <header className={`nav${scrolled ? ' scrolled' : ''}`}>
        <div className="nav-inner">
          <Link to="/" className="brand" aria-label={`${company.brand} 首页`}>
            <BrandMark size={28} />
            <span>{company.brand}</span>
          </Link>

          <nav className="nav-links" aria-label="主导航">
            {NAV_ITEMS.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.to === '/'}
                className={({ isActive }) => `nav-link${isActive ? ' active' : ''}`}
              >
                {item.label}
              </NavLink>
            ))}
          </nav>

          <div className="nav-cta" style={{ gap: '0.75rem', alignItems: 'center' }}>
            <ThemeToggle />
            <Link to="/contact" className="btn btn--primary" style={{ padding: '0.72em 1.5em', fontSize: '0.82rem' }}>
              联系我们
            </Link>
          </div>

          <button
            className={`nav-burger${open ? ' open' : ''}`}
            aria-label={open ? '关闭菜单' : '打开菜单'}
            aria-expanded={open}
            onClick={() => setOpen((v) => !v)}
          >
            <span /><span /><span />
          </button>
        </div>
      </header>

      <div className={`mobile-panel${open ? ' open' : ''}`} aria-hidden={!open}>
        <nav className="mobile-links" aria-label="移动端导航">
          {NAV_ITEMS.map((item, i) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === '/'}
              style={{ '--i': i }}
              className={({ isActive }) => `mobile-link${isActive ? ' active' : ''}`}
            >
              <span className="idx">{item.idx}</span>
              {item.label}
            </NavLink>
          ))}
          <NavLink to="/contact" style={{ '--i': NAV_ITEMS.length }} className="mobile-link">
            <span className="idx">08</span>
            联系我们
          </NavLink>
        </nav>
        <div className="mobile-foot">
          <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
            <ThemeToggle />
            <span className="fine">切换主题</span>
          </div>
          <p className="fine">{company.slogan}</p>
          <p className="fine">© {new Date().getFullYear()} {company.fullName}</p>
        </div>
      </div>
    </>
  )
}
