import React, { useState } from 'react'
import useSEO from '../hooks/useSEO'
import PageHead from '../components/PageHead'
import Reveal from '../components/Reveal'
import GlowCard from '../components/GlowCard'
import Parallax from '../components/Parallax'
import Btn from '../components/Btn'
import ParticleField from '../components/ParticleField'
import { web4 } from '../data/siteData'

/** 可交互的网络架构分层：点击展开技术要点 */
function ArchitectureLayers() {
  const [active, setActive] = useState('l2')

  return (
    <div style={{ display: 'grid', gap: '1px', background: 'var(--hairline-dark)', border: '1px solid var(--hairline-dark)', borderRadius: 'var(--radius)', overflow: 'hidden' }}>
      {web4.layers.map((row, i) => {
        const open = active === row.id
        return (
          <Reveal key={row.id} delay={0.06 * i}>
            <button
              type="button"
              className={`layer-item${open ? ' active' : ''}`}
              onClick={() => setActive(open ? '' : row.id)}
              aria-expanded={open}
            >
              <span className="eyebrow eyebrow--plain">{row.code}</span>
              <div>
                <h3 className="display-s" style={{ marginBottom: '0.5rem' }}>{row.title}</h3>
                <p className="muted">{row.desc}</p>
              </div>
              <span className="layer-sign" aria-hidden="true">{open ? '−' : '+'}</span>
            </button>
            <div className={`layer-detail${open ? ' open' : ''}`}>
              <div className="layer-detail-inner">
                <div className="layer-tags">
                  {row.detail.map((tag) => (
                    <span key={tag}>{tag}</span>
                  ))}
                </div>
              </div>
            </div>
          </Reveal>
        )
      })}
    </div>
  )
}

export default function Web4() {
  useSEO({
    title: 'Web4 技术中心',
    description:
      'AeRifvX Web4 技术中心：Web4 技术理念、区块链网络架构、数字生态协作、智能化技术应用与未来技术发展规划。'
  })

  return (
    <>
      <PageHead
        eyebrow="WEB4 TECHNOLOGY CENTER"
        title={web4.hero}
        lede="Web4 是 AeRifvX 长期技术战略的核心。我们研究并构建面向下一代互联网的开放、可信、智能的技术基础设施。"
        crumbs={[{ label: 'WEB4' }]}
      />

      {/* 技术支柱 */}
      <section className="section">
        <div className="container">
          <div className="section-head">
            <Reveal><span className="index-no">01 — 技术支柱</span></Reveal>
            <Reveal delay={0.08}>
              <h2 className="display-l">四大技术方向</h2>
            </Reveal>
          </div>

          <div className="biz-grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(min(300px, 100%), 1fr))' }}>
            {web4.pillars.map((p, i) => (
              <Reveal key={p.title} delay={0.08 * i}>
                <GlowCard className="biz-card" style={{ height: '100%' }}>
                  <span className="idx">0{i + 1}</span>
                  <h3>{p.title}</h3>
                  <p>{p.desc}</p>
                </GlowCard>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* 架构展示 */}
      <section className="section" style={{ background: 'var(--ink-850)', borderTop: '1px solid var(--hairline-dark)', borderBottom: '1px solid var(--hairline-dark)', overflow: 'hidden' }}>
        <ParticleField density={0.00005} speed={0.07} />
        <div className="container" style={{ position: 'relative', zIndex: 2 }}>
          <Parallax speed={0.05}>
            <div className="section-head">
              <Reveal><span className="index-no">02 — 网络架构</span></Reveal>
              <Reveal delay={0.08}>
                <h2 className="display-l">区块链网络架构</h2>
              </Reveal>
              <Reveal delay={0.16}>
                <p className="lede">
                  多层解耦的网络架构，兼顾性能、安全与互操作性，为上层应用提供可信执行与数据保障。
                </p>
              </Reveal>
            </div>
          </Parallax>

          <ArchitectureLayers />
          <Reveal delay={0.1}>
            <p className="fine" style={{ marginTop: '1.25rem' }}>💡 点击任意架构层，展开该层技术要点。</p>
          </Reveal>
        </div>
      </section>

      {/* 发展规划 */}
      <section className="section theme-light">
        <div className="container">
          <div className="section-head">
            <Reveal><span className="index-no">03 — 未来规划</span></Reveal>
            <Reveal delay={0.08}>
              <h2 className="display-l">技术发展路线</h2>
            </Reveal>
            <Reveal delay={0.16}>
              <p className="lede">从基础研究到全球生态协作，四个阶段稳步推进 Web4 技术落地。</p>
            </Reveal>
          </div>

          <div className="flow" style={{ background: 'var(--hairline-light)', borderColor: 'var(--hairline-light)' }}>
            {web4.roadmap.map((r, i) => (
              <Reveal key={r.phase} delay={0.08 * i}>
                <div className="flow-step" style={{ height: '100%' }}>
                  <span className="step-no">0{i + 1}</span>
                  <span className="fine">{r.phase}</span>
                  <h4>{r.title}</h4>
                  <p>{r.desc}</p>
                </div>
              </Reveal>
            ))}
          </div>

          <Reveal delay={0.15}>
            <div style={{ marginTop: '2.75rem', display: 'flex', flexWrap: 'wrap', gap: '1rem' }}>
              <Btn to="/contact" variant="primary">技术合作咨询</Btn>
              <Btn to="/services" variant="ghost">查看技术服务</Btn>
            </div>
          </Reveal>
        </div>
      </section>
    </>
  )
}
