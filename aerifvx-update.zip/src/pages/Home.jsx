import React, { useEffect, useRef } from 'react'
import { Link } from 'react-router-dom'
import useSEO from '../hooks/useSEO'
import ParticleField from '../components/ParticleField'
import Reveal from '../components/Reveal'
import CountUp from '../components/CountUp'
import GlowCard from '../components/GlowCard'
import Parallax from '../components/Parallax'
import Btn from '../components/Btn'
import Icon from '../components/Icon'
import { BrandMark } from '../components/BrandMark'
import { company, businesses, cryptoStats, announcements, globalVision, cryptoProjects } from '../data/siteData'

const lit = cryptoProjects.find((p) => p.slug === 'lit')
const minc = cryptoProjects.find((p) => p.slug === 'minc')

export default function Home() {
  useSEO({
    description:
      'AeRifvX 加密生态技术有限公司官方网站。专注加密生态、Web4、人工智能与数字技术服务，构建多元化数字生态。'
  })

  const heroRef = useRef(null)
  const glowRef = useRef(null)

  // Hero 鼠标辉光（桌面端，仅 transform）
  useEffect(() => {
    const hero = heroRef.current
    const glow = glowRef.current
    if (!hero || !glow) return
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return

    let raf = null
    let target = { x: 0, y: 0 }
    const move = (e) => {
      const rect = hero.getBoundingClientRect()
      target = { x: e.clientX - rect.left, y: e.clientY - rect.top }
      if (raf === null) {
        raf = requestAnimationFrame(() => {
          raf = null
          glow.style.transform = `translate(${target.x - 240}px, ${target.y - 240}px)`
        })
      }
    }
    hero.addEventListener('mousemove', move)
    return () => {
      hero.removeEventListener('mousemove', move)
      if (raf !== null) cancelAnimationFrame(raf)
    }
  }, [])

  const latestNews = announcements.slice(0, 3)

  return (
    <>
      {/* ============ HERO ============ */}
      <section className="hero" ref={heroRef}>
        <div className="hero-grid" />
        <div className="aurora aurora--a" />
        <div className="aurora aurora--b" />
        <ParticleField />
        <div className="cursor-glow" ref={glowRef} aria-hidden="true" />

        <div className="container hero-content">
          <Reveal>
            <span className="eyebrow">{company.tagline}</span>
          </Reveal>

          <Reveal delay={0.1}>
            <h1 className="display-xl">
              构建多元化
              <br />
              数字生态<span style={{ color: 'var(--ice-400)' }}>.</span>
            </h1>
          </Reveal>

          <Reveal delay={0.22}>
            <p className="lede">
              AeRifvX 加密生态技术有限公司成立于 {company.founded} 年。我们以区块链技术为基础，
              以创新为驱动，业务覆盖加密生态、Web4、人工智能与数字技术服务。
            </p>
          </Reveal>

          <Reveal delay={0.32}>
            <div className="hero-actions">
              <Btn to="/crypto" variant="primary">探索加密生态</Btn>
              <Btn to="/services" variant="ghost">技术服务</Btn>
            </div>
          </Reveal>

          <Reveal delay={0.42}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '1.15rem', marginTop: '0.6rem' }}>
              <BrandMark size={34} />
              <p className="fine" style={{ maxWidth: '34ch' }}>
                {company.slogan}
              </p>
            </div>
          </Reveal>
        </div>

        <div className="hero-scroll" aria-hidden="true">
          <span>SCROLL</span>
          <i />
        </div>
      </section>

      {/* ============ 核心理念 ============ */}
      <section className="section theme-light">
        <div className="container">
          <div className="section-head">
            <Reveal><span className="index-no">01 — 核心理念</span></Reveal>
            <Reveal delay={0.08}>
              <h2 className="display-l">技术为基，创新为驱</h2>
            </Reveal>
            <Reveal delay={0.16}>
              <p className="lede">
                我们相信可信的技术底座与持续的创新能力，是数字生态长期价值的来源。
              </p>
            </Reveal>
          </div>

          <div className="biz-grid">
            {company.philosophy.map((p, i) => (
              <Reveal key={p.title} delay={0.1 * i}>
                <GlowCard className="biz-card" style={{ height: '100%' }}>
                  <span className="idx">0{i + 1}</span>
                  <h3>{p.title}</h3>
                  <p>{p.desc}</p>
                </GlowCard>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ============ 业务概览 ============ */}
      <section className="section">
        <div className="container">
          <div className="section-head">
            <Reveal><span className="index-no">02 — 业务概览</span></Reveal>
            <Reveal delay={0.08}>
              <h2 className="display-l">六大业务矩阵</h2>
            </Reveal>
            <Reveal delay={0.16}>
              <p className="lede">
                从加密生态到人工智能，从工具研发到品牌数字体验 —— 多元业务协同，构成完整的数字技术服务能力。
              </p>
            </Reveal>
          </div>

          <div className="biz-grid">
            {businesses.map((b, i) => (
              <Reveal key={b.slug} delay={0.07 * (i % 3)}>
                <GlowCard style={{ height: '100%' }}>
                  <Link to={b.link.replace('#', '')} className="biz-card" style={{ height: '100%' }}>
                    <span className="idx">{b.index}</span>
                    <Icon name={b.icon} size={40} />
                    <h3>{b.title}</h3>
                    <p>{b.short}</p>
                    <span className="more">
                      了解更多 <span>→</span>
                    </span>
                  </Link>
                </GlowCard>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ============ 加密生态数据概览 ============ */}
      <section className="section" style={{ background: 'var(--ink-850)', borderTop: '1px solid var(--hairline-dark)', borderBottom: '1px solid var(--hairline-dark)' }}>
        <div className="container">
          <div className="section-head">
            <Reveal><span className="index-no">03 — 加密生态数据</span></Reveal>
            <Reveal delay={0.08}>
              <h2 className="display-l">
                生态统计市值
                <br />
                <CountUp to={39.76} decimals={2} prefix="¥" suffix=" 亿" duration={2200} />
              </h2>
            </Reveal>
            <Reveal delay={0.16}>
              <p className="lede">
                旗下加密项目市值合计约人民币 39.76 亿元（企业 {cryptoStats.statsLabel}：{cryptoStats.statsMethod}）。
              </p>
            </Reveal>
          </div>

          <div className="stat-row">
            <div className="stat-cell">
              <span className="stat-value">
                <CountUp to={39.76} decimals={2} prefix="¥" suffix=" 亿" />
              </span>
              <span className="stat-label">加密项目市值合计（{cryptoStats.statsLabel}）</span>
            </div>
            <div className="stat-cell">
              <span className="stat-value">
                <CountUp to={2025} duration={1500} />
              </span>
              <span className="stat-label">品牌创立年份</span>
            </div>
            <div className="stat-cell">
              <span className="stat-value">
                <CountUp to={6} duration={1200} suffix="+" />
              </span>
              <span className="stat-label">核心业务板块</span>
            </div>
            <div className="stat-cell">
              <span className="stat-value">2025.12.11</span>
              <span className="stat-label">LIT 项目发布</span>
            </div>
            <div className="stat-cell">
              <span className="stat-value">2026.11.27</span>
              <span className="stat-label">MINC 计划发布</span>
            </div>
          </div>

          <Reveal delay={0.12}>
            <p className="fine" style={{ marginTop: '1.75rem', maxWidth: '72ch' }}>
              ⚠ {cryptoStats.statsNote}
            </p>
          </Reveal>

          <Reveal delay={0.2}>
            <div style={{ marginTop: '2.25rem', display: 'flex', flexWrap: 'wrap', gap: '1rem' }}>
              {lit && <Btn to={`/crypto/${lit.slug}`} variant="ghost">查看 LIT 项目详情</Btn>}
              {minc && <Btn to={`/crypto/${minc.slug}`} variant="ghost">查看 MINC（计划发布）</Btn>}
            </div>
          </Reveal>
        </div>
      </section>

      {/* ============ 最新公告 ============ */}
      <section className="section theme-light">
        <div className="container">
          <div className="section-head" style={{ maxWidth: 'none', gridTemplateColumns: 'minmax(0,1fr) auto', alignItems: 'end' }}>
            <div>
              <Reveal><span className="index-no">04 — 最新公告</span></Reveal>
              <Reveal delay={0.08}>
                <h2 className="display-l">企业动态</h2>
              </Reveal>
            </div>
            <Reveal delay={0.12}>
              <Btn to="/news" variant="ghost">全部公告</Btn>
            </Reveal>
          </div>

          <div className="news-list">
            {latestNews.map((n, i) => (
              <Reveal key={n.id} delay={0.08 * i}>
                <Link to={`/news/${n.id}`} className="news-item" style={{ background: 'transparent' }}>
                  <div className="news-meta">
                    <span className="cat">{n.category}</span>
                    <time className="tnum">{n.date}</time>
                  </div>
                  <div>
                    <h3>{n.title}</h3>
                    <p>{n.summary}</p>
                  </div>
                  <span className="news-arrow" aria-hidden="true">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--ice-600)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M5 12h14M13 6l6 6-6 6" />
                    </svg>
                  </span>
                </Link>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ============ 全球化愿景 ============ */}
      <section className="section" style={{ position: 'relative', overflow: 'hidden' }}>
        <div className="aurora aurora--a" style={{ top: '-30%', right: '-14%', opacity: 0.7 }} />
        <div className="container" style={{ position: 'relative', zIndex: 2 }}>
          <Parallax speed={0.06}>
            <div className="section-head">
              <Reveal><span className="index-no">05 — 全球化愿景</span></Reveal>
              <Reveal delay={0.08}>
                <h2 className="display-l">{globalVision.title}</h2>
              </Reveal>
              <Reveal delay={0.16}>
                <p className="lede">
                  AeRifvX 面向全球市场布局，以开放、可信、智能的技术能力，与世界各地的伙伴共建数字生态。
                </p>
              </Reveal>
            </div>
          </Parallax>

          <div style={{ display: 'grid', gap: '0', borderTop: '1px solid var(--hairline-dark)' }}>
            {globalVision.points.map((p, i) => (
              <Reveal key={p.k} delay={0.09 * i}>
                <div
                  style={{
                    display: 'grid',
                    gridTemplateColumns: 'minmax(110px, 0.35fr) minmax(0, 1fr)',
                    gap: '1.5rem',
                    padding: 'clamp(1.5rem, 3vw, 2.25rem) 0',
                    borderBottom: '1px solid var(--hairline-dark)',
                    alignItems: 'baseline'
                  }}
                >
                  <span className="eyebrow eyebrow--plain">{p.k}</span>
                  <span className="display-s" style={{ fontWeight: 500 }}>{p.v}</span>
                </div>
              </Reveal>
            ))}
          </div>

          <Reveal delay={0.2}>
            <div style={{ marginTop: '3rem', display: 'flex', flexWrap: 'wrap', gap: '1rem' }}>
              <Btn to="/about" variant="primary">了解企业</Btn>
              <Btn to="/contact" variant="ghost">商务合作</Btn>
            </div>
          </Reveal>
        </div>
      </section>
    </>
  )
}
