import React, { useState } from 'react'
import useSEO from '../hooks/useSEO'
import PageHead from '../components/PageHead'
import Reveal from '../components/Reveal'
import GlowCard from '../components/GlowCard'
import Icon from '../components/Icon'
import Btn from '../components/Btn'
import Accordion from '../components/Accordion'
import { showToast } from '../components/Toast'
import { contact, company, servicesFaq } from '../data/siteData'

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

const initialForm = {
  name: '',
  company: '',
  email: '',
  type: contact.cooperationTypes[0],
  message: ''
}

/** 复制文本到剪贴板并弹出 Toast 反馈 */
async function copyText(text, okMsg) {
  try {
    await navigator.clipboard.writeText(text)
    showToast(okMsg)
  } catch {
    const ta = document.createElement('textarea')
    ta.value = text
    document.body.appendChild(ta)
    ta.select()
    try {
      document.execCommand('copy')
      showToast(okMsg)
    } catch {
      showToast('复制失败，请手动复制')
    }
    ta.remove()
  }
}

export default function Contact() {
  useSEO({
    title: '联系我们',
    description:
      'AeRifvX 商务合作、技术服务咨询与项目合作入口。填写合作申请表单，我们将尽快与您联系。'
  })

  const [form, setForm] = useState(initialForm)
  const [errors, setErrors] = useState({})
  const [status, setStatus] = useState('idle') // idle | submitting | success | error

  const validate = (values) => {
    const errs = {}
    if (!values.name.trim()) errs.name = '请填写您的称呼'
    if (!values.email.trim()) errs.email = '请填写联系邮箱'
    else if (!EMAIL_RE.test(values.email.trim())) errs.email = '邮箱格式不正确，请检查后重试'
    if (!values.message.trim()) errs.message = '请简要描述您的合作需求'
    else if (values.message.trim().length < 10) errs.message = '请至少填写 10 个字，便于我们了解需求'
    return errs
  }

  const handleChange = (e) => {
    const { name, value } = e.target
    setForm((f) => ({ ...f, [name]: value }))
    if (errors[name]) {
      setForm((f) => f)
      setErrors((prev) => {
        const next = { ...prev }
        delete next[name]
        return next
      })
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    const errs = validate(form)
    setErrors(errs)
    if (Object.keys(errs).length > 0) return

    setStatus('submitting')

    // 若配置了真实表单接口，则提交；否则进入演示成功流程
    if (contact.formEndpoint) {
      try {
        const res = await fetch(contact.formEndpoint, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(form)
        })
        if (!res.ok) throw new Error('bad response')
        setStatus('success')
      } catch {
        setStatus('error')
      }
    } else {
      await new Promise((r) => setTimeout(r, 900))
      setStatus('success')
    }
  }

  const resetForm = () => {
    setForm(initialForm)
    setErrors({})
    setStatus('idle')
  }

  return (
    <>
      <PageHead
        eyebrow="CONTACT US"
        title="联系我们"
        lede="商务合作、技术服务咨询、项目合作 —— 填写下方表单或通过邮件与我们联系。"
        crumbs={[{ label: 'CONTACT' }]}
      />

      <section className="section">
        <div className="container detail-grid">
          {/* 表单 */}
          <div>
            <Reveal>
              <div className="section-head">
                <span className="index-no">01 — 合作申请</span>
                <h2 className="display-m">告诉我们您的需求</h2>
              </div>
            </Reveal>

            {status === 'success' ? (
              <Reveal>
                <div className="form-success" role="status">
                  <div className="check">
                    <Icon name="check" size={24} />
                  </div>
                  <h3 className="display-s">提交成功，感谢您的信任</h3>
                  <p className="muted">
                    我们已收到您的合作申请（表单信息：{form.type}）。AeRifvX 团队将在 1-2 个工作日内通过邮箱
                    <strong> {form.email} </strong> 与您联系。
                  </p>
                  <p className="fine">
                    提示：本站表单为前端演示流程，未配置真实邮件接口时不会实际外发信息。企业可在配置文件中接入真实表单接口。
                  </p>
                  <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap', marginTop: '0.5rem' }}>
                    <Btn variant="ghost" arrow={false} onClick={resetForm}>再提交一份申请</Btn>
                    <Btn to="/" variant="ghost">返回首页</Btn>
                  </div>
                </div>
              </Reveal>
            ) : (
              <Reveal delay={0.1}>
                <form className="form-grid" onSubmit={handleSubmit} noValidate>
                  <div className={`form-field${errors.name ? ' invalid' : ''}`}>
                    <label htmlFor="f-name">您的称呼 *</label>
                    <input
                      id="f-name"
                      name="name"
                      value={form.name}
                      onChange={handleChange}
                      placeholder="如：张先生 / Ms. Lee"
                      aria-invalid={!!errors.name}
                      aria-describedby="e-name"
                    />
                    <span className="form-error" id="e-name">{errors.name || ''}</span>
                  </div>

                  <div className="form-field">
                    <label htmlFor="f-company">公司 / 组织</label>
                    <input
                      id="f-company"
                      name="company"
                      value={form.company}
                      onChange={handleChange}
                      placeholder="选填"
                    />
                    <span className="form-error" />
                  </div>

                  <div className={`form-field${errors.email ? ' invalid' : ''}`}>
                    <label htmlFor="f-email">联系邮箱 *</label>
                    <input
                      id="f-email"
                      name="email"
                      type="email"
                      value={form.email}
                      onChange={handleChange}
                      placeholder="you@example.com"
                      aria-invalid={!!errors.email}
                      aria-describedby="e-email"
                    />
                    <span className="form-error" id="e-email">{errors.email || ''}</span>
                  </div>

                  <div className="form-field">
                    <label htmlFor="f-type">合作类型</label>
                    <select id="f-type" name="type" value={form.type} onChange={handleChange}>
                      {contact.cooperationTypes.map((t) => (
                        <option key={t} value={t}>{t}</option>
                      ))}
                    </select>
                    <span className="form-error" />
                  </div>

                  <div className={`form-field full${errors.message ? ' invalid' : ''}`}>
                    <label htmlFor="f-message">合作需求描述 *</label>
                    <textarea
                      id="f-message"
                      name="message"
                      value={form.message}
                      onChange={handleChange}
                      placeholder="请简要描述您的项目背景、需求内容与期望的合作方式…"
                      aria-invalid={!!errors.message}
                      aria-describedby="e-message"
                    />
                    <span className="form-error" id="e-message">{errors.message || ''}</span>
                  </div>

                  <div className="form-field full" style={{ gap: '1.15rem' }}>
                    {status === 'error' && (
                      <p className="form-error" role="alert">
                        提交失败，请稍后重试或通过邮件直接联系我们。
                      </p>
                    )}
                    <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap', alignItems: 'center' }}>
                      <Btn
                        type="submit"
                        variant="primary"
                        arrow={false}
                        disabled={status === 'submitting'}
                      >
                        {status === 'submitting' ? '提交中…' : '提交合作申请'}
                      </Btn>
                      <span className="form-note">* 为必填项，我们承诺仅将信息用于本次合作沟通。</span>
                    </div>
                  </div>
                </form>
              </Reveal>
            )}
          </div>

          {/* 联系方式 */}
          <aside>
            <Reveal>
              <div className="section-head">
                <span className="index-no">02 — 联系方式</span>
                <h2 className="display-m">其他联系渠道</h2>
              </div>
            </Reveal>

            <Reveal delay={0.1}>
              <div style={{ display: 'grid', gap: '1px', background: 'var(--hairline-dark)', border: '1px solid var(--hairline-dark)', borderRadius: 'var(--radius)', overflow: 'hidden' }}>
                {/* 已提供的联系邮箱：mailto + 一键复制 */}
                {contact.emails.map((m) => (
                  <div
                    key={m.id}
                    style={{ background: 'var(--ink-850)', padding: '1.55rem 1.65rem', display: 'grid', gap: '0.85rem' }}
                  >
                    <div style={{ display: 'flex', gap: '1.15rem', alignItems: 'center' }}>
                      <Icon name="mail" size={26} />
                      <div className="fine">联系邮箱</div>
                    </div>
                    <div className="mail-row">
                      <a
                        href={`mailto:${m.address}`}
                        style={{ fontSize: 'clamp(0.98rem, 1.6vw, 1.15rem)', fontWeight: 500, wordBreak: 'break-all' }}
                      >
                        {m.address}
                      </a>
                      <button
                        type="button"
                        className="copy-btn"
                        onClick={() => copyText(m.address, `已复制邮箱：${m.address}`)}
                        aria-label={`复制邮箱 ${m.address}`}
                      >
                        复制
                      </button>
                    </div>
                  </div>
                ))}
                {[
                  { icon: 'spark', label: '公司注册地', value: contact.address, placeholder: contact.addressPlaceholder },
                  { icon: 'globe', label: '联系电话', value: contact.phone, placeholder: contact.phonePlaceholder }
                ].map((row) => (
                  <div
                    key={row.label}
                    style={{ background: 'var(--ink-850)', padding: '1.55rem 1.65rem', display: 'flex', gap: '1.15rem', alignItems: 'center' }}
                  >
                    <Icon name={row.icon} size={26} />
                    <div>
                      <div className="fine">{row.label}</div>
                      {row.value ? (
                        <div style={{ fontSize: '1.02rem', marginTop: '0.25rem' }}>{row.value}</div>
                      ) : (
                        <div style={{ fontSize: '1.02rem', marginTop: '0.25rem', color: 'var(--text-on-dark-faint)', fontStyle: 'italic' }}>
                          {row.placeholder}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </Reveal>

            <Reveal delay={0.18}>
              <GlowCard style={{ marginTop: '2rem', padding: '1.85rem' }}>
                <span className="eyebrow eyebrow--plain">RESPONSE TIME</span>
                <h3 className="display-s" style={{ margin: '0.85rem 0 0.9rem' }}>响应时效</h3>
                <p className="muted" style={{ fontSize: '0.96rem', lineHeight: 1.95 }}>
                  工作日提交的合作申请通常在 1-2 个工作日内回复。涉及技术方案的咨询，我们会安排对应领域工程师与您对接。
                </p>
                <p className="fine" style={{ marginTop: '1.15rem' }}>
                  {company.fullName} · 成立于 {company.founded} 年
                </p>
              </GlowCard>
            </Reveal>
          </aside>
        </div>
      </section>

      {/* 常见问题 */}
      <section className="section section--tight">
        <div className="container">
          <div className="section-head">
            <Reveal><span className="index-no">03 — 常见问题</span></Reveal>
            <Reveal delay={0.08}>
              <h2 className="display-m">合作前你可能想了解</h2>
            </Reveal>
          </div>
          <Reveal delay={0.14}>
            <Accordion items={servicesFaq} />
          </Reveal>
        </div>
      </section>
    </>
  )
}
