import React from 'react'
import { useParams, Link, Navigate } from 'react-router-dom'
import useSEO from '../hooks/useSEO'
import Reveal from '../components/Reveal'
import Btn from '../components/Btn'
import { announcements } from '../data/siteData'

export default function NewsDetail() {
  const { id } = useParams()
  const item = announcements.find((a) => a.id === id)
  const others = announcements.filter((a) => a.id !== id).slice(0, 2)

  useSEO({
    title: item ? item.title : '公告未找到',
    description: item ? item.summary : undefined
  })

  if (!item) return <Navigate to="/404" replace />

  return (
    <>
      {/* 文章头 */}
      <section className="page-head">
        <div className="aurora aurora--a" />
        <div className="container">
          <Reveal>
            <div className="crumbs">
              <Link to="/">HOME</Link>
              <span className="sep">/</span>
              <Link to="/news">NEWS</Link>
              <span className="sep">/</span>
              <span>{item.category}</span>
            </div>
          </Reveal>
          <Reveal delay={0.08}>
            <div style={{ display: 'flex', gap: '1.15rem', alignItems: 'center' }}>
              <span className="news-meta cat" style={{ border: '1px solid rgba(143,199,255,0.3)', color: 'var(--ice-400)', padding: '0.3em 0.95em', borderRadius: '999px', fontSize: '0.74rem', letterSpacing: '0.14em' }}>
                {item.category}
              </span>
              <time className="fine tnum">发布于 {item.date}</time>
            </div>
          </Reveal>
          <Reveal delay={0.14}>
            <h1 className="display-l" style={{ maxWidth: '22ch' }}>{item.title}</h1>
          </Reveal>
          <Reveal delay={0.2}>
            <p className="lede">{item.summary}</p>
          </Reveal>
        </div>
      </section>

      {/* 正文 */}
      <article className="section">
        <div className="container" style={{ maxWidth: '820px' }}>
          {item.body.map((para, i) => (
            <Reveal key={i} delay={0.05 * i}>
              <p
                style={{
                  fontSize: 'clamp(1.02rem, 1.4vw, 1.18rem)',
                  lineHeight: 2.1,
                  color: 'var(--text-on-dark-soft)',
                  marginBottom: '1.85rem'
                }}
              >
                {para}
              </p>
            </Reveal>
          ))}

          <Reveal delay={0.1}>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '1rem', marginTop: '2.5rem' }}>
              <Btn to="/news" variant="ghost">← 返回公告列表</Btn>
              <Btn to="/contact" variant="primary">就本公告联系我们</Btn>
            </div>
          </Reveal>

          <hr className="hairline" style={{ margin: 'var(--sp-4) 0 var(--sp-3)' }} />

          {/* 相关公告 */}
          {others.length > 0 && (
            <>
              <Reveal>
                <span className="eyebrow">RELATED · 相关公告</span>
              </Reveal>
              <div style={{ display: 'grid', gap: '1px', background: 'var(--hairline-dark)', marginTop: '1.5rem', borderBlock: '1px solid var(--hairline-dark)' }}>
                {others.map((n, i) => (
                  <Reveal key={n.id} delay={0.08 * i}>
                    <Link
                      to={`/news/${n.id}`}
                      style={{
                        background: 'var(--bg-dark)',
                        padding: '1.55rem 1.35rem',
                        display: 'grid',
                        gap: '0.55rem',
                        transition: 'background-color 0.4s'
                      }}
                      onMouseEnter={(e) => (e.currentTarget.style.background = 'var(--ink-800)')}
                      onMouseLeave={(e) => (e.currentTarget.style.background = 'var(--bg-dark)')}
                    >
                      <time className="fine tnum">{n.date} · {n.category}</time>
                      <h3 className="display-s">{n.title}</h3>
                    </Link>
                  </Reveal>
                ))}
              </div>
            </>
          )}
        </div>
      </article>
    </>
  )
}
