import React from 'react'
import useSEO from '../hooks/useSEO'
import Reveal from '../components/Reveal'
import Btn from '../components/Btn'

export default function NotFound() {
  useSEO({ title: '页面不存在' })

  return (
    <section
      className="hero"
      style={{ minHeight: '82svh', textAlign: 'left' }}
    >
      <div className="hero-grid" />
      <div className="aurora aurora--a" />
      <div className="container hero-content">
        <Reveal>
          <span className="eyebrow">ERROR 404</span>
        </Reveal>
        <Reveal delay={0.1}>
          <h1 className="display-xl">
            页面不存在<span style={{ color: 'var(--ice-400)' }}>.</span>
          </h1>
        </Reveal>
        <Reveal delay={0.2}>
          <p className="lede">
            您访问的页面可能已被移动或尚未发布。请通过下方导航回到正确的位置。
          </p>
        </Reveal>
        <Reveal delay={0.3}>
          <div className="hero-actions">
            <Btn to="/" variant="primary">返回首页</Btn>
            <Btn to="/news" variant="ghost">查看公告</Btn>
          </div>
        </Reveal>
      </div>
    </section>
  )
}
