import React from 'react'
import useSEO from '../hooks/useSEO'
import PageHead from '../components/PageHead'
import Reveal from '../components/Reveal'
import GlowCard from '../components/GlowCard'
import Btn from '../components/Btn'
import Accordion from '../components/Accordion'
import { team, teamValues, company, aboutFaq } from '../data/siteData'

export default function Team() {
  useSEO({
    title: '核心团队',
    description:
      'AeRifvX 核心团队：何开有（总负责人）、陈枫（RA-U 项目总监）。以战略定力与项目执行力驱动加密生态建设与数字技术服务。'
  })

  return (
    <>
      <PageHead
        eyebrow="OUR TEAM"
        title="核心团队"
        lede="以战略定力与项目执行力为核心，带领 AeRifvX 在加密生态、Web4 与数字技术服务方向持续投入。"
        crumbs={[{ label: 'TEAM' }]}
      />

      {/* 团队成员 */}
      <section className="section">
        <div className="container">
          <div className="section-head">
            <Reveal><span className="index-no">01 — 团队成员</span></Reveal>
            <Reveal delay={0.08}>
              <h2 className="display-l">带领 AeRifvX 前行的人</h2>
            </Reveal>
          </div>

          <div className="team-grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(min(420px, 100%), 1fr))' }}>
            {team.map((member, i) => (
              <Reveal key={member.name} delay={0.1 * i}>
                <GlowCard className="team-card" style={{ height: '100%' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '1.35rem' }}>
                    <div className="team-avatar" aria-hidden="true">{member.initial || member.name.slice(0, 1)}</div>
                    <div>
                      <div className="team-role">{member.role}</div>
                      <h3 className="team-name" style={{ marginTop: '0.55rem' }}>{member.name}</h3>
                    </div>
                  </div>
                  <p className="team-desc">{member.desc}</p>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.6rem', marginTop: '0.35rem' }}>
                    {member.focus.map((tag) => (
                      <span
                        key={tag}
                        style={{
                          padding: '0.42em 1.05em',
                          borderRadius: '999px',
                          border: '1px solid rgba(143, 199, 255, 0.28)',
                          color: 'var(--ice-300)',
                          fontSize: '0.82rem',
                          letterSpacing: '0.06em',
                          background: 'rgba(143, 199, 255, 0.07)'
                        }}
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </GlowCard>
              </Reveal>
            ))}
          </div>

          <Reveal delay={0.2}>
            <p className="fine" style={{ marginTop: '1.75rem' }}>
              团队信息由企业提供的资料整理，如需了解更详细的团队背景，欢迎通过联系邮箱与我们交流。
            </p>
          </Reveal>
        </div>
      </section>

      {/* 团队价值观 */}
      <section className="section theme-light">
        <div className="container">
          <div className="section-head">
            <Reveal><span className="index-no">02 — 团队价值观</span></Reveal>
            <Reveal delay={0.08}>
              <h2 className="display-l">我们做事的方式</h2>
            </Reveal>
            <Reveal delay={0.16}>
              <p className="lede">{company.slogan}</p>
            </Reveal>
          </div>

          <div className="biz-grid">
            {teamValues.map((v, i) => (
              <Reveal key={v.title} delay={0.08 * i}>
                <GlowCard className="biz-card" style={{ height: '100%' }}>
                  <span className="idx">0{i + 1}</span>
                  <h3>{v.title}</h3>
                  <p>{v.desc}</p>
                </GlowCard>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* 团队与业务 */}
      <section className="section">
        <div className="container">
          <div className="section-head">
            <Reveal><span className="index-no">03 — 团队与业务</span></Reveal>
            <Reveal delay={0.08}>
              <h2 className="display-m">从战略到交付的完整链路</h2>
            </Reveal>
          </div>

          <div style={{ display: 'grid', gap: '1px', background: 'var(--hairline-dark)', borderBlock: '1px solid var(--hairline-dark)' }}>
            {[
              { k: '战略层', v: '整体战略规划、生态布局与技术方向决策', who: team[0]?.name },
              { k: '项目层', v: 'RA-U 等核心项目的规划、推进与高质量交付', who: team[1]?.name },
              { k: '交付层', v: '加密生态、Web4、AI 视频、网站与 APP 等业务的研发交付', who: '研发团队' },
              { k: '生态层', v: '与全球开发者、项目方与合作伙伴的开放协作', who: '全体' }
            ].map((row, i) => (
              <Reveal key={row.k} delay={0.07 * i}>
                <div
                  style={{
                    background: 'var(--bg-dark)',
                    padding: 'clamp(1.45rem, 2.6vw, 2.15rem) clamp(1.15rem, 2.5vw, 2rem)',
                    display: 'grid',
                    gridTemplateColumns: 'minmax(90px, 0.28fr) minmax(0, 1fr) auto',
                    gap: '1.5rem',
                    alignItems: 'center'
                  }}
                >
                  <span className="eyebrow eyebrow--plain">{row.k}</span>
                  <div>
                    <p className="display-s" style={{ fontWeight: 500, fontSize: 'clamp(1.05rem, 1.7vw, 1.3rem)' }}>{row.v}</p>
                  </div>
                  <span className="fine" style={{ whiteSpace: 'nowrap' }}>{row.who}</span>
                </div>
              </Reveal>
            ))}
          </div>

          <Reveal delay={0.18}>
            <div style={{ marginTop: '2.75rem', display: 'flex', flexWrap: 'wrap', gap: '1rem' }}>
              <Btn to="/contact" variant="primary">与团队合作</Btn>
              <Btn to="/about" variant="ghost">了解企业</Btn>
            </div>
          </Reveal>
        </div>
      </section>

      {/* 常见问题 */}
      <section className="section section--tight">
        <div className="container">
          <div className="section-head">
            <Reveal><span className="index-no">04 — 常见问题</span></Reveal>
            <Reveal delay={0.08}>
              <h2 className="display-m">关于团队与企业</h2>
            </Reveal>
          </div>
          <Reveal delay={0.14}>
            <Accordion items={aboutFaq} />
          </Reveal>
        </div>
      </section>
    </>
  )
}
