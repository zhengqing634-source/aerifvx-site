import React from 'react'
import { useParams, Navigate } from 'react-router-dom'
import useSEO from '../hooks/useSEO'
import PageHead from '../components/PageHead'
import Reveal from '../components/Reveal'
import GlowCard from '../components/GlowCard'
import Btn from '../components/Btn'
import { services } from '../data/siteData'

export default function ServiceDetail() {
  const { slug } = useParams()
  const service = services.find((s) => s.slug === slug)

  useSEO({
    title: service ? service.name : '服务未找到',
    description: service ? service.intro.slice(0, 120) : undefined
  })

  if (!service) return <Navigate to="/404" replace />

  return (
    <>
      <PageHead
        eyebrow={service.nameEn}
        title={service.name}
        lede={service.lead}
        crumbs={[{ label: 'SERVICES', to: '/services' }, { label: service.name }]}
      />

      {/* 服务介绍 */}
      <section className="section">
        <div className="container detail-grid">
          <div>
            <Reveal>
              <div className="section-head">
                <span className="index-no">01 — 服务介绍</span>
                <h2 className="display-m">{service.name}</h2>
              </div>
            </Reveal>
            <Reveal delay={0.1}>
              <p className="lede">{service.intro}</p>
            </Reveal>

            <Reveal delay={0.18}>
              <div className="section-head" style={{ marginTop: 'var(--sp-4)' }}>
                <span className="index-no">02 — 技术能力</span>
                <h2 className="display-m">我们能做什么</h2>
              </div>
            </Reveal>
            <Reveal delay={0.24}>
              <ul style={{ display: 'grid', gap: '1px', background: 'var(--hairline-dark)', border: '1px solid var(--hairline-dark)', borderRadius: 'var(--radius)', overflow: 'hidden' }}>
                {service.capabilities.map((c) => (
                  <li
                    key={c}
                    style={{
                      background: 'var(--ink-850)',
                      padding: '1.25rem 1.65rem',
                      display: 'flex',
                      gap: '1rem',
                      alignItems: 'baseline',
                      fontSize: '1rem'
                    }}
                  >
                    <span style={{ color: 'var(--ice-400)', fontFamily: 'var(--font-display)', fontSize: '0.8rem', letterSpacing: '0.18em' }}>◆</span>
                    {c}
                  </li>
                ))}
              </ul>
            </Reveal>
          </div>

          {/* 服务流程 */}
          <aside>
            <Reveal>
              <div className="section-head">
                <span className="index-no">03 — 服务流程</span>
                <h2 className="display-m">四步交付</h2>
              </div>
            </Reveal>
            <Reveal delay={0.1}>
              <div className="timeline">
                {service.process.map((p) => (
                  <div className="tl-item" key={p.step}>
                    <div className="tl-date">STEP {p.step}</div>
                    <h4>{p.title}</h4>
                    <p>{p.desc}</p>
                  </div>
                ))}
              </div>
            </Reveal>

            <Reveal delay={0.2}>
              <div style={{ marginTop: '2.25rem', display: 'grid', gap: '1rem' }}>
                <Btn to="/contact" variant="primary">咨询服务方案</Btn>
                <Btn to="/services" variant="ghost">返回服务列表</Btn>
              </div>
            </Reveal>
          </aside>
        </div>
      </section>

      {/* 展示案例 */}
      <section className="section theme-light">
        <div className="container">
          <div className="section-head">
            <Reveal><span className="index-no">04 — 展示案例</span></Reveal>
            <Reveal delay={0.08}>
              <h2 className="display-m">代表性交付场景</h2>
            </Reveal>
            <Reveal delay={0.16}>
              <p className="fine">
                以下为典型交付场景示意，具体案例细节可在商务沟通中提供。
              </p>
            </Reveal>
          </div>

          <div className="biz-grid">
            {service.cases.map((c, i) => (
              <Reveal key={c.title} delay={0.08 * i}>
                <GlowCard style={{ height: '100%' }}>
                  <div className="biz-card" style={{ height: '100%' }}>
                    <span className="idx">{c.tag}</span>
                    <h3>{c.title}</h3>
                    <p>{c.desc}</p>
                  </div>
                </GlowCard>
              </Reveal>
            ))}
          </div>

          <Reveal delay={0.15}>
            <div style={{ marginTop: '2.75rem' }}>
              <Btn to="/contact" variant="primary">联系我们开始合作</Btn>
            </div>
          </Reveal>
        </div>
      </section>
    </>
  )
}
