import React from 'react'
import { Link } from 'react-router-dom'
import useSEO from '../hooks/useSEO'
import PageHead from '../components/PageHead'
import Reveal from '../components/Reveal'
import CountUp from '../components/CountUp'
import GlowCard from '../components/GlowCard'
import Accordion from '../components/Accordion'
import { cryptoProjects, cryptoStats, cryptoFaq } from '../data/siteData'

export default function Crypto() {
  useSEO({
    title: '加密生态',
    description:
      'AeRifvX 加密生态展示中心：项目介绍、区块链网络、发展历程与风险提示。企业 Q3 数据统计下加密项目市值合计约人民币 39.76 亿元。'
  })

  return (
    <>
      <PageHead
        eyebrow="CRYPTO ECOSYSTEM"
        title="加密生态展示中心"
        lede="AeRifvX 加密生态的项目矩阵与发展历程。每个项目拥有独立的详情页面与独立的数据展示。"
        crumbs={[{ label: 'CRYPTO' }]}
      />

      {/* 数据总览 */}
      <section className="section section--tight">
        <div className="container">
          <div className="stat-row">
            <div className="stat-cell">
              <span className="stat-value">
                <CountUp to={39.76} decimals={2} prefix="¥" suffix=" 亿" duration={2000} />
              </span>
              <span className="stat-label">生态项目市值合计（{cryptoStats.statsLabel}）</span>
            </div>
            <div className="stat-cell">
              <span className="stat-value">
                <CountUp to={cryptoProjects.length} duration={1200} />
              </span>
              <span className="stat-label">已发布生态项目</span>
            </div>
            <div className="stat-cell">
              <span className="stat-value">{cryptoStats.statsMethod}</span>
              <span className="stat-label">市值统计方式（{cryptoStats.statsLabel}）</span>
            </div>
          </div>

          <Reveal delay={0.1}>
            <p className="fine" style={{ marginTop: '1.5rem', maxWidth: '78ch' }}>
              ⚠ {cryptoStats.statsNote}
            </p>
          </Reveal>
        </div>
      </section>

      {/* 项目列表 */}
      <section className="section">
        <div className="container">
          <div className="section-head">
            <Reveal><span className="index-no">01 — 生态项目</span></Reveal>
            <Reveal delay={0.08}>
              <h2 className="display-l">项目矩阵</h2>
            </Reveal>
            <Reveal delay={0.16}>
              <p className="lede">
                点击进入各项目独立详情页。未公开的项目数据（如合约地址、区块链网络）将标注「待公布」，不做虚构。
                每个项目拥有独立的状态徽章与独立数据展示。
              </p>
            </Reveal>
          </div>

          <div className="biz-grid">
            {cryptoProjects.map((p, i) => (
              <Reveal key={p.slug} delay={0.1 * i}>
                <GlowCard style={{ height: '100%' }}>
                  <Link to={`/crypto/${p.slug}`} className="biz-card" style={{ height: '100%' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                      <div
                        style={{
                          width: 58,
                          height: 58,
                          borderRadius: '50%',
                          border: '1px solid rgba(143,199,255,0.4)',
                          display: 'grid',
                          placeItems: 'center',
                          fontFamily: 'var(--font-display)',
                          fontWeight: 700,
                          letterSpacing: '0.08em',
                          color: 'var(--ice-400)',
                          background: 'rgba(143,199,255,0.08)',
                          fontSize: p.logoText.length > 3 ? '0.72rem' : '0.95rem'
                        }}
                      >
                        {p.logoText}
                      </div>
                      <div>
                        <h3 style={{ marginBottom: '0.35rem' }}>{p.name}</h3>
                        <span className={`status-badge ${p.status === '计划发布' ? 'upcoming' : 'live'}`}>
                          <i className="pulse-dot" aria-hidden="true" />{p.status}
                        </span>
                      </div>
                    </div>
                    <p>{p.intro.slice(0, 78)}…</p>
                    <div style={{ display: 'grid', gap: '0.55rem' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.88rem' }}>
                        <span className="muted">{p.status === '计划发布' ? '计划发布日期' : '发布日期'}</span>
                        <span className="tnum">{p.releaseDate}</span>
                      </div>
                      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.88rem' }}>
                        <span className="muted">{p.status === '计划发布' ? '市值数据' : `市值（${cryptoStats.statsLabel}）`}</span>
                        <span className="tnum">{p.currentMarketCap.valueLabel}</span>
                      </div>
                    </div>
                    <span className="more">
                      项目详情 <span>→</span>
                    </span>
                  </Link>
                </GlowCard>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* 常见问题 */}
      <section className="section section--tight">
        <div className="container">
          <div className="section-head">
            <Reveal><span className="index-no">02 — 常见问题</span></Reveal>
            <Reveal delay={0.08}>
              <h2 className="display-m">关于数据统计与风险</h2>
            </Reveal>
          </div>
          <Reveal delay={0.14}>
            <Accordion items={cryptoFaq} />
          </Reveal>
        </div>
      </section>

      {/* 风险提示 */}
      <section className="section section--tight">
        <div className="container">
          <Reveal>
            <div className="risk-box">
              <h4>RISK DISCLAIMER · 风险提示</h4>
              <p>
                加密资产具有高波动性与高风险性，历史数据不代表未来表现。本站所载市值数据为企业 Q3 数据统计结果
                （流通供应量 × 币价），不代表实时行情。本页面不构成任何投资建议或收益承诺，
                请根据自身情况独立判断并自行承担投资风险。
              </p>
            </div>
          </Reveal>
        </div>
      </section>
    </>
  )
}
