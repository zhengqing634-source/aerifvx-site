import React from 'react'
import { Link } from 'react-router-dom'
import useSEO from '../hooks/useSEO'
import PageHead from '../components/PageHead'
import Reveal from '../components/Reveal'
import GlowCard from '../components/GlowCard'
import Icon from '../components/Icon'
import Btn from '../components/Btn'
import Accordion from '../components/Accordion'
import { services, servicesFaq } from '../data/siteData'

export default function Services() {
  useSEO({
    title: '技术服务',
    description:
      'AeRifvX 技术服务：游戏辅助工具开发、AI 视频制作、企业网站开发、APP 应用程序开发。从需求评估到交付维护的全流程服务。'
  })

  return (
    <>
      <PageHead
        eyebrow="TECHNICAL SERVICES"
        title="技术服务"
        lede="四大核心服务，从需求评估到交付维护的全流程工程能力。每一个服务拥有独立的详情页面与案例展示。"
        crumbs={[{ label: 'SERVICES' }]}
      />

      <section className="section">
        <div className="container">
          <div className="biz-grid">
            {services.map((s, i) => (
              <Reveal key={s.slug} delay={0.08 * i}>
                <GlowCard style={{ height: '100%' }}>
                  <Link to={`/services/${s.slug}`} className="biz-card" style={{ height: '100%' }}>
                    <span className="idx">{String(i + 1).padStart(2, '0')}</span>
                    <Icon name={s.icon} size={42} />
                    <h3>{s.name}</h3>
                    <p>{s.lead}</p>
                    <ul style={{ display: 'grid', gap: '0.55rem', marginTop: '0.35rem' }}>
                      {s.capabilities.slice(0, 3).map((c) => (
                        <li key={c} className="fine" style={{ display: 'flex', gap: '0.6em', alignItems: 'baseline' }}>
                          <span style={{ color: 'var(--ice-400)' }}>—</span> {c}
                        </li>
                      ))}
                    </ul>
                    <span className="more">
                      服务详情 <span>→</span>
                    </span>
                  </Link>
                </GlowCard>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="section theme-light">
        <div className="container">
          <div className="section-head">
            <Reveal><span className="index-no">— 服务承诺</span></Reveal>
            <Reveal delay={0.08}>
              <h2 className="display-l">工程化的交付标准</h2>
            </Reveal>
          </div>
          <div className="flow" style={{ background: 'var(--hairline-light)', borderColor: 'var(--hairline-light)' }}>
            {[
              { t: '透明沟通', d: '需求、进度与风险全程透明，节点化汇报。' },
              { t: '质量优先', d: '代码审查、测试覆盖与性能基线作为交付门槛。' },
              { t: '源码交付', d: '完整源码、文档与部署说明，无黑盒锁定。' },
              { t: '持续维护', d: '交付后提供版本维护与技术支持服务。' }
            ].map((c, i) => (
              <Reveal key={c.t} delay={0.08 * i}>
                <div className="flow-step" style={{ height: '100%' }}>
                  <span className="step-no">0{i + 1}</span>
                  <h4>{c.t}</h4>
                  <p>{c.d}</p>
                </div>
              </Reveal>
            ))}
          </div>

          <Reveal delay={0.15}>
            <div style={{ marginTop: '2.75rem' }}>
              <Btn to="/contact" variant="primary">获取服务方案</Btn>
            </div>
          </Reveal>
        </div>
      </section>

      {/* 常见问题 */}
      <section className="section section--tight">
        <div className="container">
          <div className="section-head">
            <Reveal><span className="index-no">— 常见问题</span></Reveal>
            <Reveal delay={0.08}>
              <h2 className="display-m">合作流程问答</h2>
            </Reveal>
          </div>
          <Reveal delay={0.14}>
            <Accordion items={servicesFaq} />
          </Reveal>
        </div>
      </section>
    </>
  )
}
