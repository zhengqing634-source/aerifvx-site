import React, { lazy, Suspense, useEffect } from 'react'
import {
  HashRouter,
  Routes,
  Route,
  useLocation,
  Navigate
} from 'react-router-dom'
import Preloader from './components/Preloader'
import Navbar from './components/Navbar'
import Footer from './components/Footer'
import ScrollToTopButton from './components/ScrollToTopButton'
import ScrollProgress from './components/ScrollProgress'
import Toast from './components/Toast'
import RouteLoader from './components/RouteLoader'
import NetworkStatus from './components/NetworkStatus'
import ErrorBoundary from './components/ErrorBoundary'

/**
 * 带自动重试的懒加载：网络抖动导致分包加载失败时，自动重试 2 次再交给错误边界
 */
function lazyWithRetry(factory, retries = 2) {
  return lazy(async () => {
    try {
      return await factory()
    } catch (err) {
      for (let i = 0; i < retries; i += 1) {
        await new Promise((r) => setTimeout(r, 900 * (i + 1)))
        try {
          return await factory()
        } catch {
          /* 继续重试 */
        }
      }
      throw err
    }
  })
}

const Home = lazyWithRetry(() => import('./pages/Home'))
const Crypto = lazyWithRetry(() => import('./pages/Crypto'))
const CryptoProject = lazyWithRetry(() => import('./pages/CryptoProject'))
const Web4 = lazyWithRetry(() => import('./pages/Web4'))
const Services = lazyWithRetry(() => import('./pages/Services'))
const ServiceDetail = lazyWithRetry(() => import('./pages/ServiceDetail'))
const About = lazyWithRetry(() => import('./pages/About'))
const Team = lazyWithRetry(() => import('./pages/Team'))
const News = lazyWithRetry(() => import('./pages/News'))
const NewsDetail = lazyWithRetry(() => import('./pages/NewsDetail'))
const Contact = lazyWithRetry(() => import('./pages/Contact'))
const NotFound = lazyWithRetry(() => import('./pages/NotFound'))

/** 路由切换：平滑回到顶部 + 页面加载状态 */
function RouteShell() {
  const location = useLocation()

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'auto' })
  }, [location.pathname])

  return (
    <ErrorBoundary resetKey={location.pathname}>
      <Suspense fallback={<RouteLoader />}>
        <div className="page-enter" key={location.pathname}>
          <Routes location={location}>
          <Route path="/" element={<Home />} />
          <Route path="/crypto" element={<Crypto />} />
          <Route path="/crypto/:slug" element={<CryptoProject />} />
          <Route path="/web4" element={<Web4 />} />
          <Route path="/services" element={<Services />} />
          <Route path="/services/:slug" element={<ServiceDetail />} />
          <Route path="/about" element={<About />} />
          <Route path="/team" element={<Team />} />
          <Route path="/news" element={<News />} />
          <Route path="/news/:id" element={<NewsDetail />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/404" element={<NotFound />} />
          <Route path="*" element={<Navigate to="/404" replace />} />
          </Routes>
        </div>
      </Suspense>
    </ErrorBoundary>
  )
}

export default function App() {
  return (
    <HashRouter>
      <Preloader />
      <ScrollProgress />
      <Navbar />
      <main>
        <RouteShell />
      </main>
      <Footer />
      <ScrollToTopButton />
      <Toast />
      <NetworkStatus />
    </HashRouter>
  )
}
