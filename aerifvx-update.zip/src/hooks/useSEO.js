import { useEffect } from 'react'

/**
 * 基础 SEO：按页面设置标题 / 描述 / Open Graph 信息
 */
export function useSEO({ title, description }) {
  useEffect(() => {
    const fullTitle = title
      ? `${title}｜AeRifvX 加密生态技术有限公司`
      : 'AeRifvX 加密生态技术有限公司｜区块链 · Web4 · AI 数字技术'
    document.title = fullTitle

    const setMeta = (selector, attr, value, create) => {
      let el = document.head.querySelector(selector)
      if (!el) {
        el = document.createElement(create)
        document.head.appendChild(el)
      }
      el.setAttribute(attr, value)
    }

    if (description) {
      setMeta('meta[name="description"]', 'content', description, 'meta')
      setMeta('meta[name="description"]', 'name', 'description', 'meta')
      setMeta('meta[property="og:title"]', 'content', fullTitle, 'meta')
      setMeta('meta[property="og:description"]', 'content', description, 'meta')
    }
  }, [title, description])
}

export default useSEO
