# AeRifvX 加密生态技术有限公司 · 官方网站

Apple 式极简 × 国际化科技企业视觉语言（黑曜石 / 银白 / 冰蓝），
基于现代 React 技术栈的完整多页面官方网站。

## 技术栈

- **React 18** + **Vite 5**（组件化、按页面代码分割、构建产物约 64KB gzip 主包）
- **React Router 6**（HashRouter，任意静态托管环境免服务端配置即可运行）
- 纯 CSS 设计系统（CSS 自定义属性 + 流式排版），零 UI 框架依赖
- Canvas 粒子背景、CSS transform/opacity 动效，全面支持 `prefers-reduced-motion`

## 快速开始

```bash
npm install        # 安装依赖
npm run dev        # 本地开发（http://localhost:5173）
npm run build      # 生产构建 → dist/
npm run preview    # 预览构建产物（http://localhost:4173）
```

## 部署

`dist/` 目录为纯静态产物（资源使用相对路径 `base: './'`），可直接部署到任意静态托管：

```bash
npm run build
# 将 dist/ 内容上传至服务器 / OSS / Pages 即可
```

### 部署到 GitHub Pages（推荐）

仓库结构中已内置 `docs/` 目录（构建产物 + `.nojekyll`）与 GitHub Actions 工作流，二选一：

**方式 A · 分支目录发布（零配置，无需 CI）**

1. 新建 GitHub 仓库并推送本项目全部文件（不含 `node_modules/`）
2. 仓库 **Settings → Pages → Build and deployment**
   - Source：`Deploy from a branch`
   - Branch：`main`，Folder：`/docs`
3. 保存后约 1 分钟，站点上线于 `https://<用户名>.github.io/<仓库名>/`
4. 以后更新：执行 `npm run build && rm -rf docs && cp -r dist docs && touch docs/.nojekyll`，提交推送即可
   （此时可删除 `.github/workflows/deploy.yml`）

**方式 B · GitHub Actions 自动部署**

1. 推送仓库后，**Settings → Pages → Build and deployment**
   - Source：`GitHub Actions`
2. 每次 push 到 `main` 自动构建并发布

> 由于使用 HashRouter 与相对资源路径，站点部署在根目录或任意子路径（如 `github.io/仓库名/`）均可正常运行，刷新、深链接不会 404。

## 网站结构

| 路由 | 页面 |
|---|---|
| `/#/` | 首页（品牌开场动画、核心理念、业务概览、加密数据、公告、全球愿景） |
| `/#/crypto` | 加密生态展示中心（项目矩阵、Q3 数据统计、风险提示） |
| `/#/crypto/lit` | LIT 项目独立详情页（发展历程、企业致谢、风险提示） |
| `/#/web4` | Web4 技术中心（技术理念、网络架构、发展规划） |
| `/#/services` | 技术服务总览 |
| `/#/services/game-assist` | 游戏辅助工具开发 |
| `/#/services/ai-video` | AI 视频制作 |
| `/#/services/web-dev` | 企业网站开发 |
| `/#/services/app-dev` | APP 应用程序开发 |
| `/#/about` | 企业介绍（简介、时间轴、愿景、核心业务） |
| `/#/news` | 公告中心（搜索、分类筛选、空状态） |
| `/#/news/:id` | 公告详情页 |
| `/#/contact` | 联系我们（表单校验、提交反馈） |
| `/#/404` | 404 页面 |

## 内容与数据修改

**所有重要数据集中在 `src/data/siteData.js`**，无需改动组件即可维护：

- `company` —— 品牌信息、企业简介、愿景、理念
- `businesses` —— 六大业务矩阵
- `cryptoStats` / `cryptoProjects` —— 加密生态统计数据与各项目独立数据
- `timeline` —— 企业发展时间轴
- `announcements` —— 公告内容（列表 / 详情 / 搜索自动生效）
- `services` —— 四大技术服务详情
- `contact` —— 联系方式（`contact.emails` 为已提供的联系邮箱，支持一键复制 / mailto）
  - **联系邮箱**：visionquestion@outlook.com / 2864182130@qq.com
  - `contact.formEndpoint`：配置真实表单接口后，合作申请表单将自动 POST 提交；
    留空则为前端演示流程（有完整的校验与成功反馈，但不外发数据）。

## 已实现的动画与交互

- 品牌 Logo 线稿描描启动动画（同会话仅播放一次，可减少动态效果时自动跳过）
- 页面切换平滑过渡、路由级懒加载（页面加载状态指示）
- 滚动进场动画、视差滚动、卡片鼠标跟随光效
- 数字滚动展示、导航栏滚动状态变化、移动端菜单展开/收回应
- 按钮点击波纹反馈、磁性按钮（鼠标靠近轻微跟随）
- 顶部阅读进度条、全站深色 / 浅色主题切换（持久化）
- FAQ 手风琴（加密生态 / 技术服务 / 联系我们）
- 邮箱一键复制 + Toast 反馈、mailto 直达
- Web4 网络架构分层交互（点击展开技术要点）
- 项目市值数据切换器（发布时 / 当前统计，带数据说明；未发布项目显示「待公布」面板）
- 公告搜索 + 分类筛选 + 空状态、表单校验与提交反馈
- 返回顶部按钮、Canvas 粒子/连线微光背景
- 全站尊重系统「减少动态效果」设置

- 项目状态徽章（已发布 / 计划发布，带呼吸指示点）
- 核心团队卡片（何开有 / 陈枫）与全站 16 个 FAQ 手风琴
- 网络状态动效：加载分级动画（网络不佳提示）、断线独立动画（重新连接）、
  加载失败独立动画（断环旋转 + 脉冲），分包自动重试，路由切换自动复位

## 数据声明

加密生态市值数据均基于企业 **Q3 数据统计**（**流通供应量 × 币价**），
**不代表实时行情**，历史数据不代表未来表现，不构成任何投资建议或收益承诺。

## 目录结构

```
aerifvx-site/
├── index.html               # SEO / 分享信息 / 字体
├── vite.config.js
├── .github/workflows/       # GitHub Pages 自动部署工作流
├── docs/                    # GitHub Pages 直发目录（构建产物 + .nojekyll）
├── src/
│   ├── main.jsx
│   ├── App.jsx              # 路由 + 懒加载 + 页面过渡
│   ├── data/siteData.js     # ★ 全站配置化数据源
│   ├── hooks/useSEO.js
│   ├── styles/global.css    # 设计系统（色板/排版/组件/动效/响应式）
│   ├── components/          # 导航/页脚/启动动画/粒子/卡片/按钮等
│   └── pages/               # 11 个独立页面
└── dist/                    # 生产构建产物（可直接部署）
```
