import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// AeRifvX 官方网站构建配置
// base 使用相对路径，保证导出后可在任意静态目录 / 子路径下运行
export default defineConfig({
  base: './',
  plugins: [react()],
  build: {
    target: 'es2018',
    cssCodeSplit: true,
    chunkSizeWarningLimit: 900
  },
  server: {
    host: '0.0.0.0',
    port: 5173
  },
  preview: {
    host: '0.0.0.0',
    port: 4173
  }
})
