/**
 * AeRifvX 官网 · 全站配置化数据源
 * ---------------------------------------------------------------
 * 所有重要业务数据集中于此文件，便于后台 / 配置文件修改，无需改动组件代码。
 * 约定：
 *  - 未提供的信息一律留空字符串或 null，界面将显示「待公布」占位，不虚构内容。
 *  - 市值类数据均带口径说明，不作为实时行情或投资依据。
 */

export const company = {
  brand: 'AeRifvX',
  fullName: 'AeRifvX 加密生态技术有限公司',
  fullNameEn: 'AeRifvX Crypto Ecosystem Technology Co., Ltd.',
  founded: '2025',
  slogan: '以区块链技术为基础，以创新为驱动，构建多元化数字生态。',
  tagline: 'BUILDING THE MULTI-DIMENSIONAL DIGITAL ECOSYSTEM',
  intro:
    'AeRifvX 加密生态技术有限公司成立于 2025 年，是一家面向全球市场的数字技术企业。公司以区块链与加密生态为根基，业务覆盖加密货币项目研发与生态建设、Web4 网络技术及生态服务、游戏辅助工具开发、AI 视频制作、企业网站开发与 APP 应用程序开发，致力于以工程能力与创新设计构建多元化的数字生态。',
  vision:
    '成为连接区块链技术与现实应用的国际化科技企业，让可信、开放、智能的数字基础设施服务于全球用户与合作伙伴。',
  philosophy: [
    {
      title: '技术为基',
      desc: '以区块链底层技术与工程化研发能力为根基，追求长期可靠的系统质量。'
    },
    {
      title: '创新驱动',
      desc: '持续探索 Web4、人工智能与数字技术的前沿方向，把创新转化为可用的产品。'
    },
    {
      title: '生态共建',
      desc: '与全球开发者、项目方与合作伙伴共建开放协作的多元数字生态。'
    }
  ]
}

/* 公司业务概览（首页 / 服务页共用） */
export const businesses = [
  {
    slug: 'crypto',
    index: '01',
    title: '加密货币项目研发与生态建设',
    short: '从项目研发、代币经济设计到长期生态运营的一体化能力。',
    icon: 'chain',
    link: '#/crypto'
  },
  {
    slug: 'web4',
    index: '02',
    title: 'Web4 网络技术及生态服务',
    short: '面向下一代互联网的网络架构、数字身份与生态协作服务。',
    icon: 'globe',
    link: '#/web4'
  },
  {
    slug: 'game-assist',
    index: '03',
    title: '游戏辅助工具开发',
    short: '性能优化、数据面板与效率工具，合规范围内提升游戏体验。',
    icon: 'game',
    link: '#/services/game-assist'
  },
  {
    slug: 'ai-video',
    index: '04',
    title: 'AI 视频制作',
    short: 'AI 驱动的视频创意、生成与后期一体化制作服务。',
    icon: 'video',
    link: '#/services/ai-video'
  },
  {
    slug: 'web-dev',
    index: '05',
    title: '企业网站开发',
    short: '国际化视觉标准的企业官网、品牌站与营销站点建设。',
    icon: 'window',
    link: '#/services/web-dev'
  },
  {
    slug: 'app-dev',
    index: '06',
    title: 'APP 应用程序开发',
    short: 'iOS / Android 跨端应用开发，从产品设计到上架运维。',
    icon: 'app',
    link: '#/services/app-dev'
  }
]

/* 加密生态数据（企业统计口径，非实时行情） */
export const cryptoStats = {
  totalMarketCapCny: 3976000000, // 约 39.76 亿元人民币
  totalMarketCapLabel: '¥39.76 亿',
  caliber: '流通供应量 × 币价',
  caliberNote:
    '上述数据为企业提供的统计口径，统计时间 2025 年 12 月，不代表实时行情，亦非第三方审计结果。加密资产价格波动剧烈，请以公开市场数据为准。',
  projectCountNote: '数据随项目进展更新'
}

/* 加密生态项目（每个项目独立详情页，数据不互相混合） */
export const cryptoProjects = [
  {
    slug: 'lit',
    name: 'LIT',
    logoText: 'LIT',
    tagline: 'AeRifvX 生态首个加密项目',
    releaseDate: '2025-12-11',
    network: '待公布', // 区块链网络
    contractAddress: null, // 仅在已提供时显示
    intro:
      'LIT 是 AeRifvX 加密生态于 2025 年 12 月 11 日发布的首个加密项目，承载着公司「以技术创新驱动生态建设」的实践起点。LIT 围绕生态协作与价值流通展开设计，后续发展规划将随项目进展逐步公开。',
    initialMarketCap: {
      valueLabel: '约 ¥2.76 万',
      note: '2025 年 12 月 11 日发布时市值（企业提供的历史数据）'
    },
    currentMarketCap: {
      valueLabel: '约 ¥39.76 亿',
      note: '企业提供的当前统计市值，口径：流通供应量 × 币价，统计时间 2025 年 12 月，非实时数据'
    },
    milestones: [
      { date: '2025-12-11', title: 'LIT 项目正式发布', desc: '发布时市值约人民币 2.76 万元。' },
      { date: '2025-12', title: '生态统计市值更新', desc: '企业统计口径下市值约人民币 39.76 亿元（非实时）。' }
    ],
    riskNote:
      '加密资产具有高波动性与高风险性，历史数据不代表未来表现。本页面不构成任何投资建议或收益承诺，请独立判断并自行承担风险。'
  }
]

/* 企业发展时间轴 */
export const timeline = [
  {
    date: '2025',
    title: 'AeRifvX 品牌创立',
    desc: 'AeRifvX 加密生态技术有限公司成立，确立「区块链为基、创新驱动」的多元化数字生态战略。'
  },
  {
    date: '2025-12-11',
    title: '发布 LIT 项目',
    desc: '生态首个加密项目 LIT 发布，发布时市值约人民币 2.76 万元，开启 AeRifvX 加密生态建设序幕。',
    highlight: true
  }
]

/* 公告中心（可由后台持续追加） */
export const announcements = [
  {
    id: 'lit-launch',
    title: 'LIT 项目正式发布公告',
    category: '项目动态',
    date: '2025-12-11',
    summary: 'AeRifvX 加密生态首个项目 LIT 于 2025 年 12 月 11 日正式发布。',
    body: [
      'AeRifvX 加密生态技术有限公司正式宣布：加密生态首个项目 LIT 于 2025 年 12 月 11 日发布。',
      'LIT 项目发布时市值约为人民币 2.76 万元（企业提供的历史数据）。截至 2025 年 12 月，企业统计口径下（流通供应量 × 币价）市值约为人民币 39.76 亿元，该数据非实时行情，亦非第三方审计结果。',
      '感谢全球加密生态参与者与投资者一直以来的支持。AeRifvX 将继续坚持技术创新与生态建设，持续探索区块链技术的应用价值。',
      '风险提示：加密资产价格波动剧烈，历史数据不代表未来表现，本公告不构成任何投资建议。'
    ]
  },
  {
    id: 'brand-founding',
    title: 'AeRifvX 品牌创立公告',
    category: '企业公告',
    date: '2025-01-01',
    summary: 'AeRifvX 加密生态技术有限公司于 2025 年正式创立，聚焦区块链与数字技术服务。',
    body: [
      'AeRifvX 加密生态技术有限公司于 2025 年正式创立。',
      '公司以区块链技术为基础，以创新为驱动，业务覆盖加密货币项目研发与生态建设、Web4 网络技术及生态服务、游戏辅助工具开发、AI 视频制作、企业网站开发与 APP 应用程序开发。',
      '我们将以国际化的技术标准与设计语言，持续为全球客户与合作伙伴交付高质量的数字产品与服务。'
    ]
  },
  {
    id: 'web4-research',
    title: 'Web4 技术研发方向说明',
    category: '技术研究',
    date: '2025-06-01',
    summary: 'AeRifvX 公布 Web4 网络技术研究方向，覆盖网络架构、数字身份与智能化应用。',
    body: [
      'AeRifvX 技术团队公布 Web4 研究与开发方向，重点覆盖去中心化网络架构、数字身份体系、智能化技术应用与数字生态协作机制。',
      'Web4 是 AeRifvX 长期技术战略的重要组成部分。相关技术成果将随研发进度在技术中心页面持续更新。'
    ]
  }
]

/* 技术服务（四个独立业务） */
export const services = [
  {
    slug: 'game-assist',
    name: '游戏辅助工具开发',
    nameEn: 'GAME TOOL ENGINEERING',
    icon: 'game',
    lead: '在合规前提下，为游戏玩家与发行团队打造性能优化、数据面板与效率工具。',
    intro:
      'AeRifvX 提供面向游戏场景的辅助工具研发服务，覆盖数据采集与可视化面板、操作效率工具、性能优化组件等。我们坚持合规开发边界，所有工具均在游戏许可与法律规范范围内使用。',
    capabilities: [
      '实时数据面板与战绩分析系统',
      '性能监控、帧率与延迟优化组件',
      '自动化效率工具与宏脚本框架（合规场景）',
      '跨平台工具链：Windows / macOS / 移动端',
      '反作弊兼容设计与安全审计'
    ],
    process: [
      { step: '01', title: '需求评估', desc: '明确使用场景与合规边界，输出可行性评估。' },
      { step: '02', title: '方案设计', desc: '确定技术栈、数据接口与交互原型。' },
      { step: '03', title: '开发联调', desc: '模块化开发、接口联调与性能压测。' },
      { step: '04', title: '交付维护', desc: '交付源码与文档，提供持续版本维护。' }
    ],
    cases: [
      { title: '电竞数据面板', desc: '为战队提供的实时数据可视化与复盘系统。', tag: '数据分析' },
      { title: '性能优化组件', desc: '帧率与网络延迟优化模块，平均延迟降低可感知。', tag: '性能' },
      { title: '效率工具集', desc: '面向内容创作者的批量操作与自动化效率工具。', tag: '效率' }
    ]
  },
  {
    slug: 'ai-video',
    name: 'AI 视频制作',
    nameEn: 'AI VIDEO PRODUCTION',
    icon: 'video',
    lead: '从创意脚本到成片交付，AI 驱动的视频内容工业化制作。',
    intro:
      'AeRifvX 的 AI 视频制作服务融合生成式 AI 与专业后期流程，覆盖品牌宣传片、产品演示、社交媒体短视频与动画内容。我们以工业化流程保证交付质量与效率。',
    capabilities: [
      'AI 分镜脚本与创意策划',
      'AI 生成画面、动画与视觉特效',
      '专业剪辑、调色与声音设计',
      '多语言字幕与本地化版本交付',
      '4K 高码率成片与多平台适配版本'
    ],
    process: [
      { step: '01', title: '创意沟通', desc: '明确目标受众、传播场景与品牌调性。' },
      { step: '02', title: '脚本分镜', desc: 'AI 辅助生成脚本与分镜，人工审核定稿。' },
      { step: '03', title: '制作合成', desc: 'AI 生成 + 专业后期合成、配音与调色。' },
      { step: '04', title: '成片交付', desc: '多版本成片交付与投放适配建议。' }
    ],
    cases: [
      { title: '品牌宣传片', desc: '科技企业品牌视觉影片，全片 AI 辅助生成。', tag: '品牌' },
      { title: '产品演示动画', desc: 'SaaS 产品功能演示动画，多语言版本交付。', tag: '产品' },
      { title: '社交短视频系列', desc: '批量生成的系列化短视频内容。', tag: '内容' }
    ]
  },
  {
    slug: 'web-dev',
    name: '企业网站开发',
    nameEn: 'CORPORATE WEB DEVELOPMENT',
    icon: 'window',
    lead: '以国际化设计语言打造企业官网、品牌站与营销站点。',
    intro:
      'AeRifvX 提供高端企业网站与品牌数字体验的全流程开发服务，从视觉设计、前端工程到内容管理与 SEO 优化，帮助企业在数字世界建立可信、专业、国际化的第一印象。',
    capabilities: [
      '品牌官网 / 营销站 / 活动站设计开发',
      '响应式工程：桌面、平板、移动端全适配',
      '动效设计与高性能渲染优化',
      'SEO 架构、多语言与内容管理集成',
      '可访问性（无障碍）与性能评分优化'
    ],
    process: [
      { step: '01', title: '品牌调研', desc: '梳理品牌定位、竞品与目标受众。' },
      { step: '02', title: '视觉设计', desc: '输出设计语言、页面视觉与动效规范。' },
      { step: '03', title: '开发上线', desc: '组件化开发、内容接入与多端测试。' },
      { step: '04', title: '运营支持', desc: '上线后数据分析、迭代与运维支持。' }
    ],
    cases: [
      { title: '科技企业官网', desc: '深浅双主题、全动效的国际化品牌官网。', tag: '品牌' },
      { title: '加密项目门户', desc: '项目展示、数据概览与公告系统一体化门户。', tag: 'Web3' },
      { title: '产品营销站', desc: '高转化率的产品落地页与营销活动站。', tag: '营销' }
    ]
  },
  {
    slug: 'app-dev',
    name: 'APP 应用程序开发',
    nameEn: 'MOBILE APP DEVELOPMENT',
    icon: 'app',
    lead: '从产品设计到上架运维，交付高质量的 iOS 与 Android 应用。',
    intro:
      'AeRifvX 提供移动应用全流程研发服务，覆盖产品原型、UI/UX 设计、跨端开发、后端服务与应用商店上架。我们以工程化标准交付稳定、流畅、可扩展的应用产品。',
    capabilities: [
      'iOS / Android 原生与跨端开发',
      '产品原型、UI/UX 设计与设计系统',
      '后端服务、API 网关与数据架构',
      '推送、支付、地图等第三方能力集成',
      '应用商店上架、灰度发布与运维监控'
    ],
    process: [
      { step: '01', title: '产品定义', desc: '需求拆解、原型设计与技术选型。' },
      { step: '02', title: '设计开发', desc: '设计系统搭建与迭代式开发。' },
      { step: '03', title: '测试上线', desc: '多机型测试、性能调优与商店上架。' },
      { step: '04', title: '持续迭代', desc: '数据驱动的版本迭代与运维保障。' }
    ],
    cases: [
      { title: '数字资产管理应用', desc: '多链资产查看与提醒的移动应用。', tag: '金融' },
      { title: '内容社区 APP', desc: '内容流、互动与创作者工具一体化社区应用。', tag: '社区' },
      { title: '企业效率工具', desc: '面向企业内部的流程与协作移动应用。', tag: '企业' }
    ]
  }
]

/* Web4 技术中心 */
export const web4 = {
  hero: '面向下一代互联网的开放技术架构',
  pillars: [
    {
      title: 'Web4 技术理念',
      desc: '从「可读、可写、可拥有」走向「可协同」的智能网络，让价值、身份与智能体在可信底座上自由协作。'
    },
    {
      title: '区块链网络架构',
      desc: '多层网络架构设计，覆盖共识层、执行层、数据可用性层与跨链互操作协议。'
    },
    {
      title: '数字生态协作',
      desc: '以开放协议连接开发者、项目方与用户，共建共享的生态协作与激励机制。'
    },
    {
      title: '智能化技术应用',
      desc: '将 AI 智能体与链上基础设施结合，探索自动化协作、智能合约生成与数据智能。'
    }
  ],
  /** 网络架构分层（可交互展开） */
  layers: [
    {
      id: 'l4',
      code: 'L4 · APPLICATION',
      title: '应用与生态层',
      desc: '面向真实场景的 DApp、智能体与生态服务。',
      detail: ['去中心化应用运行时', 'AI 智能体协作框架', '生态激励与治理工具', '开发者 SDK 与 API 网关']
    },
    {
      id: 'l3',
      code: 'L3 · INTEROP',
      title: '跨链互操作层',
      desc: '跨链消息、资产桥与多链路由协议。',
      detail: ['跨链消息传递协议', '资产桥与流动性路由', '多链身份映射', '互操作安全审计']
    },
    {
      id: 'l2',
      code: 'L2 · EXECUTION',
      title: '执行与计算层',
      desc: '高性能执行环境、Rollup 与计算分片。',
      detail: ['高性能虚拟机执行环境', 'Rollup 扩容方案', '计算分片与并行执行', '零知识证明加速']
    },
    {
      id: 'l1',
      code: 'L1 · CONSENSUS',
      title: '共识与数据层',
      desc: '共识机制、数据可用性与安全基座。',
      detail: ['BFT / PoS 混合共识', '数据可用性采样', '密码学安全基座', '网络层抗攻击设计']
    }
  ],
  roadmap: [
    { phase: '阶段一', title: '基础设施研究', desc: '网络架构、共识机制与数字身份体系研究。' },
    { phase: '阶段二', title: '协议与工具链', desc: '开发者工具链、SDK 与协议标准化建设。' },
    { phase: '阶段三', title: '生态应用落地', desc: '面向真实场景的 Web4 应用与生态服务上线。' },
    { phase: '阶段四', title: '全球生态协作', desc: '与全球伙伴共建跨域、跨链的开放数字生态。' }
  ]
}

/* 联系方式：未提供的渠道使用可配置占位字段，不做虚构 */
export const contact = {
  /** 已提供的联系邮箱（点击可复制 / mailto） */
  emails: [
    { id: 'mail-1', address: 'visionquestion@outlook.com' },
    { id: 'mail-2', address: '2864182130@qq.com' }
  ],
  email: '', // 备用单邮箱字段（留空时界面使用 emails 列表）
  emailPlaceholder: '待公布',
  address: '',
  addressPlaceholder: '待公布',
  phone: '',
  phonePlaceholder: '待公布',
  /** 若配置真实接口地址，表单将 POST 至该地址；留空则为前端演示模式 */
  formEndpoint: '',
  cooperationTypes: ['商务合作', '技术服务咨询', '项目合作', '媒体与品牌', '其他']
}

/* 加密生态常见问题（风险与口径） */
export const cryptoFaq = [
  {
    q: '市值数据是如何统计的？',
    a: '统计口径为「流通供应量 × 币价」，由企业自行统计，统计时间 2025 年 12 月。该数据不代表实时行情，也未经第三方审计，请以公开市场数据为准。'
  },
  {
    q: '历史市值数据是否代表未来收益？',
    a: '不代表。加密资产价格波动剧烈，历史数据仅反映过去某一时间点的统计结果，不构成任何投资建议或收益承诺。AeRifvX 不承诺任何投资回报。'
  },
  {
    q: '为什么部分项目信息显示「待公布」？',
    a: '区块链网络、合约地址等信息在企业正式提供并确认之前，我们不做虚构填充，统一显示「待公布」。信息确认后将在项目详情页及时更新。'
  },
  {
    q: '如何获取项目的最新动态？',
    a: '可通过「公告中心」查看企业公告与项目动态，或通过「联系我们」页面的邮箱与我们取得联系。'
  }
]

/* 技术服务常见问题 */
export const servicesFaq = [
  {
    q: '一个项目的开发周期一般多久？',
    a: '取决于项目规模与复杂度。中小型工具类项目通常 2-6 周，企业级网站 4-10 周，APP 应用 8-16 周。需求评估阶段会给出明确的排期与里程碑。'
  },
  {
    q: '是否提供源码与后期维护？',
    a: '提供。所有项目交付完整源码、文档与部署说明，并提供版本维护与技术支持服务，无黑盒锁定。'
  },
  {
    q: '如何开始合作？',
    a: '通过「联系我们」页面填写合作申请表单，或直接发送邮件说明需求。我们会安排对应领域工程师在 1-2 个工作日内与您对接。'
  },
  {
    q: '游戏辅助工具开发的合规边界是什么？',
    a: '所有工具均在游戏许可协议与法律规范范围内开发与使用，包含反作弊兼容设计。涉及破坏游戏公平性的需求我们不承接。'
  }
]

/* 全球化愿景 */
export const globalVision = {
  title: '全球化发展愿景',
  points: [
    { k: 'GLOBAL', v: '面向全球市场提供技术与生态服务' },
    { k: 'OPEN', v: '以开放协议与标准参与国际协作' },
    { k: 'TRUST', v: '以工程质量与透明沟通建立长期信任' }
  ]
}

export const footerLinks = [
  {
    group: '探索',
    links: [
      { label: '首页', to: '/' },
      { label: '加密生态', to: '/crypto' },
      { label: 'Web4 技术中心', to: '/web4' }
    ]
  },
  {
    group: '服务',
    links: [
      { label: '游戏辅助开发', to: '/services/game-assist' },
      { label: 'AI 视频制作', to: '/services/ai-video' },
      { label: '企业网站开发', to: '/services/web-dev' },
      { label: 'APP 应用开发', to: '/services/app-dev' }
    ]
  },
  {
    group: '公司',
    links: [
      { label: '企业介绍', to: '/about' },
      { label: '公告中心', to: '/news' },
      { label: '联系我们', to: '/contact' }
    ]
  }
]
