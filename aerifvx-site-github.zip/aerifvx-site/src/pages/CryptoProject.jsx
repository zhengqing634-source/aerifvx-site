import React, { useState } from 'react'
import { useParams, Link, Navigate } from 'react-router-dom'
import useSEO from '../hooks/useSEO'
import PageHead from '../components/PageHead'
import Reveal from '../components/Reveal'
import GlowCard from '../components/GlowCard'
import Btn from '../components/Btn'
import { cryptoProjects, company } from '../data/siteData'

/** LIT 市值数据切换器（发布时 / 当前统计），带口径声明 */
function MetricSwitch({ project }) {
  const [period, setPeriod] = useState('initial')
  const data = period === 'initial' ? project.initialMarketCap : project.currentMarketCap

  return (
    <div style={{ display: 'grid', gap: '1.35rem' }}>
      <div className="metric-switch" role="tablist" aria-label="市值数据切换">
        <button
          type="button"
          role="tab"
          aria-selected={period === 'initial'}
          className={period === 'initial' ? 'active' : ''}
          onClick={() => setPeriod('initial')}
        >
          发布时市值
        </button>
        <button
          type="button"
          role="tab"
          aria-selected={period === 'current'}
          className={period === 'current' ? 'active' : ''}
          onClick={() => setPeriod('current')}
        >
          当前统计市值
        </button>
      </div>
      <div className="metric-display" key={period}>
        <div style={{ fontSize: 'clamp(2.4rem, 6vw, 4.25rem)', fontFamily: 'var(--font-display)', fontWeight: 700, letterSpacing: '-0.03em', lineHeight: 1.05 }}>
          {data.valueLabel}
        </div>
        <p className="fine" style={{ marginTop: '0.85rem', maxWidth: '58ch' }}>{data.note}</p>
      </div>
    </div>
  )
}

export default function CryptoProject() {
  const { slug } = useParams()
  const project = cryptoProjects.find((p) => p.slug === slug)

  useSEO({
    title: project ? `${project.name} 项目` : '项目未找到',
    description: project ? project.intro.slice(0, 120) : undefined
  })

  if (!project) return <Navigate to="/404" replace />

  return (
    <>
      <PageHead
        eyebrow="CRYPTO ECOSYSTEM · PROJECT"
        title={`${project.name}｜${project.tagline}`}
        lede={project.intro}
        crumbs={[{ label: 'CRYPTO', to: '/crypto' }, { label: project.name }]}
      />

      {/* 项目关键信息 */}
      <section className="section">
        <div className="container detail-grid">
          <div>
            <Reveal>
              <div className="section-head" style={{ marginBottom: 'var(--sp-3)' }}>
                <span className="index-no">01 — 项目信息</span>
                <h2 className="display-m">基础信息与统计口径</h2>
              </div>
            </Reveal>

            <Reveal delay={0.1}>
              <dl className="info-table">
                <div className="info-row">
                  <dt>项目名称</dt>
                  <dd>{project.name}</dd>
                </div>
                <div className="info-row">
                  <dt>发布日期</dt>
                  <dd className="tnum">{project.releaseDate}</dd>
                </div>
                <div className="info-row">
                  <dt>区块链网络</dt>
                  <dd className={project.network === '待公布' ? 'pending' : ''}>{project.network}</dd>
                </div>
                <div className="info-row">
                  <dt>合约地址</dt>
                  <dd className="pending">
                    {project.contractAddress || '待公布（企业未提供，暂不展示）'}
                  </dd>
                </div>
                <div className="info-row">
                  <dt>发布时市值</dt>
                  <dd>
                    <strong className="tnum">{project.initialMarketCap.valueLabel}</strong>
                    <div className="fine">{project.initialMarketCap.note}</div>
                  </dd>
                </div>
                <div className="info-row">
                  <dt>统计市值</dt>
                  <dd>
                    <strong className="tnum">{project.currentMarketCap.valueLabel}</strong>
                    <div className="fine">{project.currentMarketCap.note}</div>
                  </dd>
                </div>
              </dl>
            </Reveal>

            <Reveal delay={0.12}>
              <div className="section-head" style={{ marginBottom: 'var(--sp-3)' }}>
                <span className="index-no">03 — 市值数据对比</span>
                <h2 className="display-m">历史与当前统计</h2>
              </div>
            </Reveal>
            <Reveal delay={0.18}>
              <MetricSwitch project={project} />
            </Reveal>

            <Reveal delay={0.24}>
              <div className="risk-box" style={{ marginTop: '2rem' }}>
                <h4>RISK DISCLAIMER · 风险提示</h4>
                <p>{project.riskNote}</p>
              </div>
            </Reveal>
          </div>

          {/* 发展历程 */}
          <aside>
            <Reveal>
              <div className="section-head" style={{ marginBottom: 'var(--sp-3)' }}>
                <span className="index-no">02 — 发展历程</span>
                <h2 className="display-m">项目里程碑</h2>
              </div>
            </Reveal>

            <Reveal delay={0.1}>
              <div className="timeline">
                {project.milestones.map((m) => (
                  <div className="tl-item highlight" key={m.date + m.title}>
                    <div className="tl-date tnum">{m.date}</div>
                    <h4>{m.title}</h4>
                    <p>{m.desc}</p>
                  </div>
                ))}
              </div>
            </Reveal>

            <Reveal delay={0.2}>
              <GlowCard style={{ marginTop: '2.25rem', padding: '1.85rem' }}>
                <span className="eyebrow eyebrow--plain">ENTERPRISE MESSAGE</span>
                <h3 className="display-s" style={{ margin: '0.9rem 0 1rem' }}>企业致谢</h3>
                <p className="muted" style={{ fontSize: '0.96rem', lineHeight: 1.95 }}>
                  “感谢全球加密生态参与者与投资者一直以来的支持。AeRifvX 将继续坚持技术创新与生态建设，
                  持续探索区块链技术的应用价值，为未来交付更加满意的答卷。”
                </p>
                <p className="fine" style={{ marginTop: '1.15rem' }}>
                  —— {company.fullName}
                </p>
              </GlowCard>
            </Reveal>
          </aside>
        </div>
      </section>

      {/* 项目详情补充 */}
      <section className="section theme-light">
        <div className="container">
          <div className="section-head">
            <Reveal><span className="index-no">03 — 关于 LIT</span></Reveal>
            <Reveal delay={0.08}>
              <h2 className="display-m">项目愿景与生态定位</h2>
            </Reveal>
          </div>
          <Reveal delay={0.14}>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(min(320px, 100%), 1fr))', gap: '1px', background: 'var(--hairline-light)', border: '1px solid var(--hairline-light)', borderRadius: 'var(--radius)', overflow: 'hidden' }}>
              <div style={{ background: '#fff', padding: 'clamp(1.75rem, 3vw, 2.5rem)', display: 'grid', gap: '0.85rem' }}>
                <span className="eyebrow eyebrow--plain" style={{ color: 'var(--ice-600)' }}>ECOLOGY</span>
                <h3 className="display-s">生态起点</h3>
                <p className="muted" style={{ fontSize: '0.96rem' }}>
                  LIT 作为 AeRifvX 加密生态的首个项目，是公司从技术研究走向生态实践的第一步。
                </p>
              </div>
              <div style={{ background: '#fff', padding: 'clamp(1.75rem, 3vw, 2.5rem)', display: 'grid', gap: '0.85rem' }}>
                <span className="eyebrow eyebrow--plain" style={{ color: 'var(--ice-600)' }}>TECHNOLOGY</span>
                <h3 className="display-s">技术创新</h3>
                <p className="muted" style={{ fontSize: '0.96rem' }}>
                  以区块链技术为基础，持续探索加密技术在真实场景中的应用价值。
                </p>
              </div>
              <div style={{ background: '#fff', padding: 'clamp(1.75rem, 3vw, 2.5rem)', display: 'grid', gap: '0.85rem' }}>
                <span className="eyebrow eyebrow--plain" style={{ color: 'var(--ice-600)' }}>LONG-TERM</span>
                <h3 className="display-s">长期主义</h3>
                <p className="muted" style={{ fontSize: '0.96rem' }}>
                  不承诺投资回报，以长期生态建设与技术交付回应参与者的信任。
                </p>
              </div>
            </div>
          </Reveal>

          <Reveal delay={0.2}>
            <div style={{ marginTop: '2.5rem', display: 'flex', flexWrap: 'wrap', gap: '1rem' }}>
              <Btn to="/crypto" variant="primary">返回加密生态</Btn>
              <Btn to="/contact" variant="ghost">项目合作咨询</Btn>
            </div>
          </Reveal>
        </div>
      </section>
    </>
  )
}
