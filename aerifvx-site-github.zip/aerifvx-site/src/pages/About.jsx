import React from 'react'
import useSEO from '../hooks/useSEO'
import PageHead from '../components/PageHead'
import Reveal from '../components/Reveal'
import GlowCard from '../components/GlowCard'
import Btn from '../components/Btn'
import CountUp from '../components/CountUp'
import { company, timeline, businesses, globalVision, cryptoProjects } from '../data/siteData'

export default function About() {
  useSEO({
    title: '企业介绍',
    description:
      'AeRifvX 加密生态技术有限公司成立于 2025 年，专注加密生态、Web4、人工智能与数字技术开发。了解企业发展历程、愿景与核心业务。'
  })

  return (
    <>
      <PageHead
        eyebrow="ABOUT AERIFVX"
        title="关于 AeRifvX"
        lede={company.slogan}
        crumbs={[{ label: 'ABOUT' }]}
      />

      {/* 企业简介 */}
      <section className="section">
        <div className="container detail-grid">
          <div>
            <Reveal>
              <div className="section-head">
                <span className="index-no">01 — 企业简介</span>
                <h2 className="display-l">以技术驱动的<br />数字生态企业</h2>
              </div>
            </Reveal>
            <Reveal delay={0.12}>
              <p className="lede">{company.intro}</p>
            </Reveal>
          </div>

          <Reveal delay={0.2}>
            <div className="stat-row" style={{ gridTemplateColumns: '1fr 1fr', border: '1px solid var(--hairline-dark)', borderRadius: 'var(--radius)', overflow: 'hidden' }}>
              <div className="stat-cell">
                <span className="stat-value"><CountUp to={2025} duration={1400} /></span>
                <span className="stat-label">成立年份</span>
              </div>
              <div className="stat-cell">
                <span className="stat-value"><CountUp to={6} suffix="+" duration={1200} /></span>
                <span className="stat-label">核心业务</span>
              </div>
              <div className="stat-cell">
                <span className="stat-value"><CountUp to={39.76} decimals={2} prefix="¥" suffix=" 亿" duration={2000} /></span>
                <span className="stat-label">生态项目统计市值</span>
              </div>
              <div className="stat-cell">
                <span className="stat-value">2025.12.11</span>
                <span className="stat-label">LIT 项目发布</span>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* 发展历程时间轴 */}
      <section className="section" style={{ background: 'var(--ink-850)', borderTop: '1px solid var(--hairline-dark)', borderBottom: '1px solid var(--hairline-dark)' }}>
        <div className="container">
          <div className="section-head">
            <Reveal><span className="index-no">02 — 品牌发展历程</span></Reveal>
            <Reveal delay={0.08}>
              <h2 className="display-l">从创立到生态启航</h2>
            </Reveal>
          </div>

          <Reveal delay={0.12}>
            <div className="timeline" style={{ maxWidth: '860px' }}>
              {timeline.map((t) => (
                <div className={`tl-item${t.highlight ? ' highlight' : ''}`} key={t.date + t.title}>
                  <div className="tl-date tnum">{t.date}</div>
                  <h4>{t.title}</h4>
                  <p>{t.desc}</p>
                  {t.highlight && cryptoProjects[0] && (
                    <div style={{ marginTop: '1.15rem' }}>
                      <Btn to={`/crypto/${cryptoProjects[0].slug}`} variant="ghost" arrow={false}>
                        查看 LIT 项目详情 →
                      </Btn>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </Reveal>
        </div>
      </section>

      {/* 企业愿景 */}
      <section className="section theme-light">
        <div className="container">
          <div className="section-head">
            <Reveal><span className="index-no">03 — 企业愿景</span></Reveal>
            <Reveal delay={0.08}>
              <h2 className="display-l">我们想成为什么</h2>
            </Reveal>
            <Reveal delay={0.16}>
              <p className="lede">{company.vision}</p>
            </Reveal>
          </div>

          <div className="biz-grid">
            {company.philosophy.map((p, i) => (
              <Reveal key={p.title} delay={0.09 * i}>
                <GlowCard className="biz-card" style={{ height: '100%' }}>
                  <span className="idx">0{i + 1}</span>
                  <h3>{p.title}</h3>
                  <p>{p.desc}</p>
                </GlowCard>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* 核心业务 */}
      <section className="section">
        <div className="container">
          <div className="section-head">
            <Reveal><span className="index-no">04 — 核心业务</span></Reveal>
            <Reveal delay={0.08}>
              <h2 className="display-l">六大业务板块</h2>
            </Reveal>
          </div>

          <div style={{ display: 'grid', gap: '1px', background: 'var(--hairline-dark)', borderBlock: '1px solid var(--hairline-dark)' }}>
            {businesses.map((b, i) => (
              <Reveal key={b.slug} delay={0.05 * i}>
                <a
                  href={`#${b.link.replace('#', '')}`}
                  style={{
                    background: 'var(--bg-dark)',
                    padding: 'clamp(1.35rem, 2.5vw, 2rem) clamp(1.15rem, 2.5vw, 2rem)',
                    display: 'grid',
                    gridTemplateColumns: 'minmax(60px, 0.15fr) minmax(0, 1fr) auto',
                    gap: '1.5rem',
                    alignItems: 'center',
                    transition: 'background-color 0.4s var(--ease-out)'
                  }}
                  onMouseEnter={(e) => (e.currentTarget.style.background = 'var(--ink-800)')}
                  onMouseLeave={(e) => (e.currentTarget.style.background = 'var(--bg-dark)')}
                >
                  <span className="idx" style={{ fontFamily: 'var(--font-display)', fontSize: '0.82rem', letterSpacing: '0.28em', color: 'var(--ice-500)' }}>
                    {b.index}
                  </span>
                  <div>
                    <h3 className="display-s" style={{ marginBottom: '0.35rem' }}>{b.title}</h3>
                    <p className="muted" style={{ fontSize: '0.94rem' }}>{b.short}</p>
                  </div>
                  <span style={{ color: 'var(--ice-400)' }}>→</span>
                </a>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* 全球生态合作理念 */}
      <section className="section theme-light">
        <div className="container">
          <div className="section-head">
            <Reveal><span className="index-no">05 — 全球生态合作</span></Reveal>
            <Reveal delay={0.08}>
              <h2 className="display-l">{globalVision.title}</h2>
            </Reveal>
            <Reveal delay={0.16}>
              <p className="lede">
                我们以开放的姿态与全球伙伴合作，共同推动区块链技术与数字生态的边界。
              </p>
            </Reveal>
          </div>

          <div className="flow" style={{ background: 'var(--hairline-light)', borderColor: 'var(--hairline-light)' }}>
            {globalVision.points.map((p, i) => (
              <Reveal key={p.k} delay={0.08 * i}>
                <div className="flow-step" style={{ height: '100%' }}>
                  <span className="step-no">{String(i + 1).padStart(2, '0')}</span>
                  <span className="fine">{p.k}</span>
                  <p style={{ fontSize: '1.05rem', color: 'var(--text-on-light)' }}>{p.v}</p>
                </div>
              </Reveal>
            ))}
          </div>

          <Reveal delay={0.15}>
            <div style={{ marginTop: '2.75rem', display: 'flex', flexWrap: 'wrap', gap: '1rem' }}>
              <Btn to="/contact" variant="primary">成为合作伙伴</Btn>
              <Btn to="/news" variant="ghost">企业公告</Btn>
            </div>
          </Reveal>
        </div>
      </section>
    </>
  )
}
