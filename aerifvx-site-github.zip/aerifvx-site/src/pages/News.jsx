import React, { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import useSEO from '../hooks/useSEO'
import PageHead from '../components/PageHead'
import Reveal from '../components/Reveal'
import Icon from '../components/Icon'
import { announcements } from '../data/siteData'

const CATEGORIES = ['全部', ...Array.from(new Set(announcements.map((a) => a.category)))]

export default function News() {
  useSEO({
    title: '公告中心',
    description: 'AeRifvX 公告中心：企业公告、项目动态与技术研究的最新信息。'
  })

  const [query, setQuery] = useState('')
  const [category, setCategory] = useState('全部')

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase()
    return announcements
      .filter((a) => (category === '全部' ? true : a.category === category))
      .filter((a) =>
        q
          ? a.title.toLowerCase().includes(q) ||
            a.summary.toLowerCase().includes(q) ||
            a.body.join(' ').toLowerCase().includes(q)
          : true
      )
      .sort((a, b) => (a.date < b.date ? 1 : -1))
  }, [query, category])

  return (
    <>
      <PageHead
        eyebrow="NEWS & ANNOUNCEMENTS"
        title="公告中心"
        lede="AeRifvX 企业公告、项目动态与技术研究发布。支持按分类筛选与关键词搜索。"
        crumbs={[{ label: 'NEWS' }]}
      />

      <section className="section">
        <div className="container">
          {/* 搜索 & 筛选 */}
          <div className="news-toolbar">
            <label className="search-box">
              <Icon name="search" size={18} />
              <input
                type="search"
                placeholder="搜索公告标题或关键词…"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                aria-label="搜索公告"
              />
              {query && (
                <button
                  onClick={() => setQuery('')}
                  aria-label="清除搜索"
                  style={{ background: 'none', border: 0, cursor: 'pointer', color: 'var(--text-on-dark-soft)', fontSize: '1.1rem' }}
                >
                  ×
                </button>
              )}
            </label>

            <div className="filter-chips" role="group" aria-label="公告分类筛选">
              {CATEGORIES.map((c) => (
                <button
                  key={c}
                  className={`chip${category === c ? ' active' : ''}`}
                  onClick={() => setCategory(c)}
                >
                  {c}
                </button>
              ))}
            </div>
          </div>

          {/* 结果计数 */}
          <p className="fine" style={{ marginBottom: '1.25rem' }}>
            共 {filtered.length} 条公告
            {query && <>，关键词「{query}」</>}
            {category !== '全部' && <>，分类「{category}」</>}
          </p>

          {/* 列表 / 空状态 */}
          {filtered.length > 0 ? (
            <div className="news-list">
              {filtered.map((n, i) => (
                <Reveal key={n.id} delay={0.06 * i}>
                  <Link to={`/news/${n.id}`} className="news-item">
                    <div className="news-meta">
                      <span className="cat">{n.category}</span>
                      <time className="tnum">{n.date}</time>
                    </div>
                    <div>
                      <h3>{n.title}</h3>
                      <p>{n.summary}</p>
                    </div>
                    <span className="news-arrow" aria-hidden="true">
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--ice-400)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M5 12h14M13 6l6 6-6 6" />
                      </svg>
                    </span>
                  </Link>
                </Reveal>
              ))}
            </div>
          ) : (
            <div className="empty-state">
              <div className="ring">
                <Icon name="search" size={26} />
              </div>
              <h3 className="display-s">未找到相关公告</h3>
              <p className="muted" style={{ maxWidth: '42ch' }}>
                没有匹配「{query || category}」的公告内容。请尝试更换关键词，或查看全部公告。
              </p>
              <button
                className="btn btn--ghost"
                onClick={() => {
                  setQuery('')
                  setCategory('全部')
                }}
              >
                重置筛选条件
              </button>
            </div>
          )}
        </div>
      </section>
    </>
  )
}
