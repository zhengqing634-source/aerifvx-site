import React from 'react'
import { Link } from 'react-router-dom'
import { BrandMark } from './BrandMark'
import { company, footerLinks, contact } from '../data/siteData'

export default function Footer() {
  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-top">
          <div>
            <Link to="/" className="brand">
              <BrandMark size={28} />
              <span>{company.brand}</span>
            </Link>
            <p className="muted" style={{ maxWidth: '38ch', fontSize: '0.95rem' }}>
              {company.slogan}
            </p>
            <p className="fine" style={{ marginTop: '1.35rem' }}>
              联系邮箱：
            </p>
            <ul style={{ display: 'grid', gap: '0.4rem', marginTop: '0.35rem' }}>
              {contact.emails.map((m) => (
                <li key={m.id}>
                  <a className="fine" href={`mailto:${m.address}`} style={{ transition: 'color 0.3s' }}>
                    {m.address}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {footerLinks.map((group) => (
            <div className="footer-group" key={group.group}>
              <h4>{group.group}</h4>
              <ul>
                {group.links.map((link) => (
                  <li key={link.to}>
                    <Link to={link.to}>{link.label}</Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="footer-bottom">
          <span>© {new Date().getFullYear()} {company.fullName} · 保留所有权利</span>
          <span className="fine">
            本站加密生态数据为企业统计口径（流通供应量 × 币价），非实时行情，不构成投资建议。
          </span>
        </div>
      </div>

      <div className="footer-wordmark" aria-hidden="true">AERIFVX</div>
    </footer>
  )
}
