import React, { lazy, Suspense, useEffect } from 'react'
import {
  HashRouter,
  Routes,
  Route,
  useLocation,
  Navigate
} from 'react-router-dom'
import Preloader from './components/Preloader'
import Navbar from './components/Navbar'
import Footer from './components/Footer'
import ScrollToTopButton from './components/ScrollToTopButton'
import ScrollProgress from './components/ScrollProgress'
import Toast from './components/Toast'

const Home = lazy(() => import('./pages/Home'))
const Crypto = lazy(() => import('./pages/Crypto'))
const CryptoProject = lazy(() => import('./pages/CryptoProject'))
const Web4 = lazy(() => import('./pages/Web4'))
const Services = lazy(() => import('./pages/Services'))
const ServiceDetail = lazy(() => import('./pages/ServiceDetail'))
const About = lazy(() => import('./pages/About'))
const News = lazy(() => import('./pages/News'))
const NewsDetail = lazy(() => import('./pages/NewsDetail'))
const Contact = lazy(() => import('./pages/Contact'))
const NotFound = lazy(() => import('./pages/NotFound'))

/** 路由切换：平滑回到顶部 + 页面加载状态 */
function RouteShell() {
  const location = useLocation()

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'auto' })
  }, [location.pathname])

  return (
    <Suspense
      fallback={
        <div className="route-loader" role="status" aria-label="页面加载中">
          <div className="spinner" />
        </div>
      }
    >
      <div className="page-enter" key={location.pathname}>
        <Routes location={location}>
          <Route path="/" element={<Home />} />
          <Route path="/crypto" element={<Crypto />} />
          <Route path="/crypto/:slug" element={<CryptoProject />} />
          <Route path="/web4" element={<Web4 />} />
          <Route path="/services" element={<Services />} />
          <Route path="/services/:slug" element={<ServiceDetail />} />
          <Route path="/about" element={<About />} />
          <Route path="/news" element={<News />} />
          <Route path="/news/:id" element={<NewsDetail />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/404" element={<NotFound />} />
          <Route path="*" element={<Navigate to="/404" replace />} />
        </Routes>
      </div>
    </Suspense>
  )
}

export default function App() {
  return (
    <HashRouter>
      <Preloader />
      <ScrollProgress />
      <Navbar />
      <main>
        <RouteShell />
      </main>
      <Footer />
      <ScrollToTopButton />
      <Toast />
    </HashRouter>
  )
}
